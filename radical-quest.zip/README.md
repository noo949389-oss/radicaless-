# ⚔️ Radical Quest: Domina el Poder de las Raíces

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![HTML5 / Vanilla JS](https://img.shields.io/badge/Tech-HTML5%20%7C%20CSS3%20%7C%20Vanilla%20JS-blue)](https://developer.mozilla.org/es/docs/Web/JavaScript)
[![Web Audio API](https://img.shields.io/badge/Audio-Web%20Audio%20API%20Procedural-purple)](https://developer.mozilla.org/es/docs/Web/API/Web_Audio_API)
[![Educational Level](https://img.shields.io/badge/Nivel-Secundaria%20y%20Preparatoria-green)](#)

> **Un videojuego educativo, interactivo y visualmente atractivo sobre el tema de los RADICALES MATEMÁTICOS (ÁLGEBRA).**

---

## 🌟 Descripción General

**Radical Quest** es una aventura matemática diseñada para estudiantes de secundaria y preparatoria. En lugar de resolver aburridas listas de ejercicios estáticos, el jugador se adentra en un mundo fantástico dividido en **7 reinos temáticos**, donde cada reino representa un tema fundamental del álgebra radical. 

Para avanzar y salvar el cosmos matemático, el jugador deberá comprender la teoría desde cero, simplificar expresiones algebraicas, resolver operaciones paso a paso y derrotar a guardianes y monstruos matemáticos en combates RPG por turnos.

---

## 🗺️ Los 7 Reinos Matemáticos

```mermaid
flowchart LR
    R1["🌱 1. Bosque del Origen<br/>¿Qué son los Radicales?"] --> R2["💎 2. Cavernas del Índice<br/>Tipos de Raíces"]
    R2 --> R3["🏛️ 3. Templo de las Leyes<br/>Propiedades y Fórmulas"]
    R3 --> R4["🔨 4. Forja de Simplificación<br/>Extracción de Factores"]
    R4 --> R5["⚔️ 5. Valle de Operaciones<br/>Suma, Resta, Mult, Div"]
    R5 --> R6["🌊 6. Cascada Racionalización<br/>Monomios y Conjugados"]
    R6 --> R7["⚡ 7. Torre Cuántica<br/>Exponentes Fraccionarios"]
    R7 --> FIN["👑 Gran Ciudadela<br/>Examen Final (20 Desafíos)"]
```

1. **🌱 Reino 1: El Bosque del Origen**  
   * Definición de radical y radicación como inversa de la potenciación ($b^n = a \iff \sqrt[n]{a} = b$).
   * Partes de un radical: coeficiente, índice, signo radical, radicando y raíz.
   * Diagrama interactivo y aplicaciones en geometría y física.
2. **💎 Reino 2: Las Cavernas del Índice**  
   * Raíz cuadrada, cúbica, cuarta y quinta.
   * Regla de signos: ¡por qué las raíces de índice impar sí admiten radicandos negativos ($\sqrt[3]{-8} = -2$) y las pares en $\mathbb{R}$ no!
   * Raíces exactas vs. números irracionales.
3. **🏛️ Reino 3: El Templo de las Leyes**  
   * Raíz de un producto: $\sqrt[n]{a \cdot b} = \sqrt[n]{a} \cdot \sqrt[n]{b}$.
   * Raíz de un cociente: $\sqrt[n]{\frac{a}{b}} = \frac{\sqrt[n]{a}}{\sqrt[n]{b}}$.
   * Potencia de un radical y raíz de una raíz ($\sqrt[m]{\sqrt[n]{a}} = \sqrt[m \cdot n]{a}$).
4. **🔨 Reino 4: La Forja de la Simplificación**  
   * Descomposición en factores primos y búsqueda de cuadrados perfectos máximos.
   * Extracción de factores con la regla del cociente y residuo.
   * Ejemplo resuelto paso a paso: $\sqrt{72} = \sqrt{36 \times 2} = 6\sqrt{2}$.
5. **⚔️ Reino 5: El Valle de las Operaciones**  
   * Criterio de radicales semejantes (mismo índice y mismo radicando).
   * Suma y resta de semejantes y simplificación previa ($\sqrt{12} + \sqrt{27} = 5\sqrt{3}$).
   * Multiplicación y división con igual índice.
6. **🌊 Reino 6: La Cascada de la Racionalización**  
   * Eliminación de radicales del denominador sin alterar el valor numérico.
   * Caso 1: Monomio con raíz cuadrada multiplicando por el '1 conveniente'.
   * Caso 2: Binomios conjugados mediante diferencia de cuadrados $(a+b)(a-b) = a^2 - b^2$.
7. **⚡ Reino 7: La Torre del Infinito Cuántico**  
   * Equivalencia universal: $\sqrt[n]{a^m} = a^{\frac{m}{n}}$.
   * Conversión en ambas direcciones y leyes de exponentes aplicadas a raíces.
8. **👑 La Gran Ciudadela del Rey Radical**  
   * Examen final integrador de 20 preguntas que abarca todos los temas.
   * Diploma y certificación personalizada de *Maestro Supremo*.

---

## 🎮 Mecánicas de Juego

* **Combate RPG por Turnos:** El estudiante responde a los acertijos del monstruo. Las respuestas correctas generan impactos mágicos críticos con animaciones y efectos de sacudida.
* **Teclado Matemático Virtual:** Permite introducir raíces cuadradas ($\sqrt{}$), exponentes ($x^2$), fracciones y variables con un solo clic.
* **Modo Contrarreloj (Torbellino Radical):** 60 segundos de preguntas rápidas con multiplicador de combos para entrenar agilidad mental.
* **Economía y Progresión:** Monedas de oro mágicas, puntos de experiencia (XP), niveles de personaje y sistema de 3 vidas.
* **Códice de Fórmulas:** Un compendio interactivo con buscador en vivo para consultar propiedades en cualquier momento.
* **Audio Procedural:** Generador de música y efectos de sonido con Web Audio API (cero descargas externas, 100% offline).

---

## 🚀 Despliegue en GitHub Pages (Jugar Online Gratis)

Para alojar el juego gratis en GitHub y compartirlo con estudiantes y profesores:

1. Crea un repositorio público en GitHub llamado `radical-quest`.
2. Sube los archivos de este proyecto al repositorio.
3. Ve a **Settings (Configuración)** > **Pages**.
4. En **Branch**, selecciona `main` (o `master`) y la carpeta `/(root)`.
5. Haz clic en **Save**.
6. ¡En un minuto tendrás tu juego disponible en línea en:  
   `https://<tu-usuario>.github.io/radical-quest/`!

---

## 📂 Estructura del Proyecto

```
radical-quest/
├── index.html        # Estructura principal y pantallas del videojuego
├── styles.css        # Estilos modernos de fantasía RPG y animaciones
├── game.js           # Lógica del juego, combate, teclado interactivo y estado
├── math-data.js      # Banco curricular de los 7 reinos, fórmulas y preguntas
├── audio.js          # Sintetizador procedural de audio (Web Audio API)
├── README.md         # Documentación oficial del proyecto
└── LICENSE           # Licencia MIT
```

---

## 📄 Licencia

Este proyecto es de código abierto bajo la licencia [MIT](LICENSE). Siéntete libre de utilizarlo, adaptarlo y mejorarlo para fines educativos.
