// ==========================================================================
// RADICAL QUEST: MOTOR PRINCIPAL DEL JUEGO
// Gestión de Estados, Combate RPG, Evaluaciones y Renderizado Matemático
// ==========================================================================

// Motor de Renderizado Matemático Ligero (Convierte LaTeX básico a HTML estético)
const MathRenderer = {
  render(text) {
    if (!text) return "";
    let formatted = text;

    // Reemplazar bloques de ecuaciones $$...$$
    formatted = formatted.replace(/\$\$([\s\S]*?)\$\$/g, (match, formula) => {
      return `<div class="math-formula-box">${this.renderFormula(formula.trim())}</div>`;
    });

    // Reemplazar ecuaciones en línea $...$
    formatted = formatted.replace(/\$([^\$]+?)\$/g, (match, formula) => {
      return `<span class="math-tex">${this.renderFormula(formula.trim())}</span>`;
    });

    // Reemplazar markdown básico
    formatted = formatted.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    formatted = formatted.replace(/\*(.*?)\*/g, '<em>$1</em>');
    formatted = formatted.replace(/\n\n/g, '<p></p>');

    return formatted;
  },

  renderFormula(f) {
    let s = f;

    // Símbolos especiales
    s = s.replace(/\\iff/g, ' ⟺ ');
    s = s.replace(/\\implies/g, ' ⟹ ');
    s = s.replace(/\\cdot/g, ' · ');
    s = s.replace(/\\times/g, ' × ');
    s = s.replace(/\\neq/g, ' ≠ ');
    s = s.replace(/\\pm/g, ' ± ');
    s = s.replace(/\\mp/g, ' ∓ ');
    s = s.replace(/\\ge/g, ' ≥ ');
    s = s.replace(/\\le/g, ' ≤ ');
    s = s.replace(/\\in/g, ' ∈ ');
    s = s.replace(/\\mathbb\{R\}/g, 'ℝ');
    s = s.replace(/\\text\{([^\}]+)\}/g, '$1');

    // Raíz con índice: \sqrt[n]{radicando}
    s = s.replace(/\\sqrt\[([^\]]+)\]\{([^\}]+)\}/g, (m, idx, rad) => {
      return `<span class="math-sqrt"><sup class="math-sqrt-idx">${idx}</sup><span class="math-sqrt-symbol">√</span><span class="math-sqrt-radicand">${this.renderFormula(rad)}</span></span>`;
    });

    // Raíz cuadrada simple: \sqrt{radicando}
    s = s.replace(/\\sqrt\{([^\}]+)\}/g, (m, rad) => {
      return `<span class="math-sqrt"><span class="math-sqrt-symbol">√</span><span class="math-sqrt-radicand">${this.renderFormula(rad)}</span></span>`;
    });

    // Fracciones: \frac{num}{den}
    s = s.replace(/\\frac\{([^\}]+)\}\{([^\}]+)\}/g, (m, num, den) => {
      return `<span class="math-frac"><span class="math-num">${this.renderFormula(num)}</span><span class="math-den">${this.renderFormula(den)}</span></span>`;
    });

    // Superíndices y exponentes: x^{abc} o x^2
    s = s.replace(/\^\{([^\}]+)\}/g, '<sup class="math-sup">$1</sup>');
    s = s.replace(/\^([0-9a-zA-Z\+\-]+)/g, '<sup class="math-sup">$1</sup>');

    // Subíndices: x_{abc} o x_2
    s = s.replace(/_\{([^\}]+)\}/g, '<sub class="math-sub">$1</sub>');
    s = s.replace(/_([0-9a-zA-Z])/g, '<sub class="math-sub">$1</sub>');

    return s;
  }
};

// ==========================================================================
// ESTADO GLOBAL DEL JUGADOR Y PROGRESIÓN
// ==========================================================================
class GameState {
  constructor() {
    this.storageKey = "radical_quest_save_v1";
    this.defaultState = {
      hero: {
        name: "Aria la Conjuradora",
        avatar: "🧙‍♀️",
        rank: "Iniciado Radical",
        level: 1,
        xp: 0,
        gold: 50,
        hearts: 3,
        maxHearts: 3
      },
      unlockedRealms: [1],
      realmStars: {},
      realmHighscores: {},
      achievements: [],
      speedHighscore: 0,
      soundEnabled: true,
      musicEnabled: false
    };

    this.state = this.load();
  }

  load() {
    try {
      const saved = localStorage.getItem(this.storageKey);
      if (saved) {
        return { ...this.defaultState, ...JSON.parse(saved) };
      }
    } catch (e) {
      console.warn("Error cargando guardado:", e);
    }
    return { ...this.defaultState };
  }

  save() {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.state));
    } catch (e) {
      console.warn("Error guardando progreso:", e);
    }
    this.updateHUD();
  }

  reset() {
    this.state = { ...this.defaultState };
    this.save();
  }

  addXP(amount) {
    this.state.hero.xp += amount;
    const requiredXP = this.state.hero.level * 100;
    if (this.state.hero.xp >= requiredXP) {
      this.state.hero.level++;
      this.state.hero.xp -= requiredXP;
      this.updateRank();
      if (window.soundManager) window.soundManager.playLevelClear();
      return true; // Subió de nivel
    }
    return false;
  }

  addGold(amount) {
    this.state.hero.gold += amount;
    if (window.soundManager) window.soundManager.playCoin();
    this.save();
  }

  updateRank() {
    const lvl = this.state.hero.level;
    if (lvl >= 10) this.state.hero.rank = "Archimago del Infinito";
    else if (lvl >= 7) this.state.hero.rank = "Maestro Supremo de las Raíces";
    else if (lvl >= 5) this.state.hero.rank = "Erudito Alquimista";
    else if (lvl >= 3) this.state.hero.rank = "Hechicero Radical";
    else this.state.hero.rank = "Iniciado Radical";
  }

  unlockRealm(realmId) {
    if (!this.state.unlockedRealms.includes(realmId)) {
      this.state.unlockedRealms.push(realmId);
      this.save();
    }
  }

  unlockAchievement(achId) {
    if (!this.state.achievements.includes(achId)) {
      this.state.achievements.push(achId);
      this.save();
      this.showToastAchievement(achId);
    }
  }

  showToastAchievement(achId) {
    const ach = RADICAL_QUEST_DATA.achievements.find(a => a.id === achId);
    if (!ach) return;
    const toast = document.createElement("div");
    toast.className = "achievement-toast";
    toast.innerHTML = `
      <div style="font-size:2rem">${ach.icon}</div>
      <div>
        <div style="font-size:0.75rem; color:#f59e0b; font-weight:700;">¡LOGRO DESBLOQUEADO!</div>
        <div style="font-weight:700; color:#fff;">${ach.title}</div>
        <div style="font-size:0.8rem; color:#cbd5e1;">${ach.desc}</div>
      </div>
    `;
    toast.style.cssText = `
      position: fixed; bottom: 20px; right: 20px; background: rgba(15, 23, 42, 0.95);
      border: 2px solid #f59e0b; border-radius: 12px; padding: 12px 18px;
      display: flex; align-items: center; gap: 12px; z-index: 9999;
      box-shadow: 0 0 25px rgba(245, 158, 11, 0.5); animation: fadeIn 0.4s ease;
    `;
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transition = "opacity 0.5s ease";
      setTimeout(() => toast.remove(), 500);
    }, 4000);
  }

  updateHUD() {
    const nameEl = document.getElementById("hud-hero-name");
    const rankEl = document.getElementById("hud-hero-rank");
    const avatarEl = document.getElementById("hud-hero-avatar");
    const heartsEl = document.getElementById("hud-hearts");
    const goldEl = document.getElementById("hud-gold");
    const xpEl = document.getElementById("hud-xp");

    if (nameEl) nameEl.textContent = this.state.hero.name;
    if (rankEl) rankEl.textContent = `Nvl. ${this.state.hero.level} · ${this.state.hero.rank}`;
    if (avatarEl) avatarEl.textContent = this.state.hero.avatar;
    if (heartsEl) heartsEl.textContent = "❤️".repeat(Math.max(0, this.state.hero.hearts));
    if (goldEl) goldEl.textContent = this.state.hero.gold;
    if (xpEl) xpEl.textContent = `XP ${this.state.hero.xp}/${this.state.hero.level * 100}`;
  }
}

// Instancia global
window.gameState = new GameState();

// ==========================================================================
// CONTROLADOR PRINCIPAL DEL JUEGO (GAME APP)
// ==========================================================================
class RadicalQuestApp {
  constructor() {
    this.currentScreen = "title";
    this.currentRealm = null;
    this.currentBattle = null;
    this.currentExam = null;
    this.isFinalExam = false;
    this.speedTimer = null;
    this.speedTimeLeft = 60;
    this.speedScore = 0;

    this.initDOM();
    this.initCanvasBackground();
    this.renderWorldMap();
    this.renderCodex();
    this.renderAchievements();
  }

  initDOM() {
    window.gameState.updateHUD();

    // Eventos de botones de pantalla de inicio
    document.getElementById("btn-play-start")?.addEventListener("click", () => {
      if (window.soundManager) window.soundManager.playClick();
      this.showScreen("map");
    });

    document.getElementById("btn-learn-start")?.addEventListener("click", () => {
      if (window.soundManager) window.soundManager.playClick();
      this.openLesson(1);
    });

    document.getElementById("btn-formulas-start")?.addEventListener("click", () => {
      if (window.soundManager) window.soundManager.playClick();
      this.showScreen("codex");
    });

    document.getElementById("btn-speed-start")?.addEventListener("click", () => {
      if (window.soundManager) window.soundManager.playClick();
      this.startSpeedRush();
    });

    document.getElementById("btn-achievements-start")?.addEventListener("click", () => {
      if (window.soundManager) window.soundManager.playClick();
      this.showScreen("achievements");
    });

    // Botones de HUD global
    document.getElementById("hud-btn-map")?.addEventListener("click", () => {
      if (window.soundManager) window.soundManager.playClick();
      this.showScreen("map");
    });

    document.getElementById("hud-btn-codex")?.addEventListener("click", () => {
      if (window.soundManager) window.soundManager.playClick();
      this.showScreen("codex");
    });

    document.getElementById("hud-btn-sound")?.addEventListener("click", () => {
      if (window.soundManager) {
        const isMuted = window.soundManager.toggleMute();
        const icon = document.getElementById("hud-btn-sound");
        if (icon) icon.textContent = isMuted ? "🔇" : "🔊";
      }
    });

    document.getElementById("hud-btn-music")?.addEventListener("click", () => {
      if (window.soundManager) {
        const isPlaying = window.soundManager.toggleBGM();
        const icon = document.getElementById("hud-btn-music");
        if (icon) icon.textContent = isPlaying ? "🎵" : "🎶";
      }
    });

    // Búsqueda en el códice
    document.getElementById("codex-search-input")?.addEventListener("input", (e) => {
      this.filterCodex(e.target.value);
    });
  }

  showScreen(screenId) {
    document.querySelectorAll(".screen").forEach(s => s.classList.add("hidden"));
    const target = document.getElementById(`screen-${screenId}`);
    if (target) {
      target.classList.remove("hidden");
      this.currentScreen = screenId;
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }

  // ========================================================================
  // RENDERIZADO DEL MAPA DE REINOS
  // ========================================================================
  renderWorldMap() {
    const grid = document.getElementById("realms-grid-container");
    if (!grid) return;
    grid.innerHTML = "";

    const unlocked = window.gameState.state.unlockedRealms;

    RADICAL_QUEST_DATA.realms.forEach(realm => {
      const isUnlocked = unlocked.includes(realm.id);
      const stars = window.gameState.state.realmStars[realm.id] || 0;
      const starsDisplay = "⭐".repeat(stars) + "☆".repeat(3 - stars);

      const card = document.createElement("div");
      card.className = `realm-card ${isUnlocked ? "" : "locked"}`;
      card.innerHTML = `
        <span class="realm-badge-num">Reino ${realm.id}</span>
        <div class="realm-icon-banner">${realm.icon}</div>
        <h3>${realm.title}</h3>
        <div class="realm-topic">${realm.subtitle}</div>
        <div class="realm-boss-preview">
          <span>${realm.boss.avatar}</span>
          <span>Jefe: ${realm.boss.name}</span>
        </div>
        <div class="realm-stars">${starsDisplay}</div>
        <div class="realm-actions">
          <button class="btn-realm-learn" data-realm-id="${realm.id}">
            📖 Aprender
          </button>
          <button class="btn-realm-battle" data-realm-id="${realm.id}" ${isUnlocked ? "" : "disabled"}>
            ⚔️ Desafío
          </button>
        </div>
      `;

      card.querySelector(".btn-realm-learn")?.addEventListener("click", () => {
        if (window.soundManager) window.soundManager.playClick();
        this.openLesson(realm.id);
      });

      card.querySelector(".btn-realm-battle")?.addEventListener("click", () => {
        if (!isUnlocked) return;
        if (window.soundManager) window.soundManager.playClick();
        this.startRealmBattle(realm.id);
      });

      grid.appendChild(card);
    });

    // Tarjeta de la Gran Ciudadela (Examen Final de 20 preguntas)
    const citadelContainer = document.getElementById("citadel-card-container");
    if (citadelContainer) {
      const allRealmsCompleted = RADICAL_QUEST_DATA.realms.every(r => (window.gameState.state.realmStars[r.id] || 0) > 0);
      citadelContainer.innerHTML = `
        <div class="citadel-card ${allRealmsCompleted ? "" : "locked"}">
          <div style="font-size: 4rem; margin-bottom: 0.5rem;">👑</div>
          <h2 style="color: #fde047; font-size: 1.8rem; margin-bottom: 0.5rem;">
            ${RADICAL_QUEST_DATA.finalExam.title}
          </h2>
          <p style="color: #cbd5e1; max-width: 650px; margin-bottom: 1.25rem;">
            ${RADICAL_QUEST_DATA.finalExam.description}
          </p>
          <div style="font-size: 0.9rem; color: #f59e0b; margin-bottom: 1.25rem;">
            ${allRealmsCompleted ? "¡El portal de la Ciudadela está abierto!" : "🔒 Requiere completar los 7 reinos para desbloquear"}
          </div>
          <button id="btn-start-final-exam" class="btn-hero btn-hero-primary" ${allRealmsCompleted ? "" : "disabled"}>
            🐲 Enfrentar al Dragón Emperador (20 Preguntas)
          </button>
        </div>
      `;

      document.getElementById("btn-start-final-exam")?.addEventListener("click", () => {
        if (allRealmsCompleted) {
          if (window.soundManager) window.soundManager.playClick();
          this.startFinalExam();
        }
      });
    }
  }

  // ========================================================================
  // SECCIÓN DE APRENDIZAJE (GRIMORIO)
  // ========================================================================
  openLesson(realmId) {
    const realm = RADICAL_QUEST_DATA.realms.find(r => r.id === realmId);
    if (!realm) return;

    this.currentRealm = realm;
    const container = document.getElementById("lesson-content-container");
    if (!container) return;

    let sectionsHTML = "";
    realm.lesson.sections.forEach(sec => {
      let extra = "";
      if (sec.formula) {
        extra += `<div class="math-formula-box">${MathRenderer.renderFormula(sec.formula)}</div>`;
      }
      if (sec.interactiveDiagram) {
        extra += `
          <div style="background: rgba(15, 23, 42, 0.7); border: 2px dashed #8b5cf6; border-radius: 14px; padding: 1.5rem; text-align: center; margin: 1rem 0;">
            <div style="font-size: 0.85rem; color: #a78bfa; margin-bottom: 0.75rem; text-transform: uppercase; font-weight:700;">Diagrama Anatómico del Radical</div>
            <div style="font-size: 2.2rem; font-family: serif; color: #fff; margin-bottom: 1rem;">
              <span style="color: #38bdf8; font-weight: bold;" title="Coeficiente">3</span>
              <sup style="color: #f59e0b; font-size: 1.1rem; font-weight: bold; position: relative; top: -0.6em;" title="Índice">4</sup>
              <span style="color: #ec4899; font-size: 2.6rem;" title="Signo Radical">√</span>
              <span style="border-top: 3px solid #ec4899; padding: 0 0.4em; color: #10b981; font-weight: bold;" title="Radicando">16</span>
              <span style="color: #94a3b8;"> = </span>
              <span style="color: #fde047; font-weight: bold;" title="Raíz">6</span>
            </div>
            <div style="display: flex; flex-wrap: wrap; justify-content: center; gap: 0.8rem; font-size: 0.8rem;">
              <span style="background: rgba(56, 189, 248, 0.2); border: 1px solid #38bdf8; color: #38bdf8; padding: 4px 8px; border-radius: 6px;">3 = Coeficiente</span>
              <span style="background: rgba(245, 158, 11, 0.2); border: 1px solid #f59e0b; color: #f59e0b; padding: 4px 8px; border-radius: 6px;">4 = Índice</span>
              <span style="background: rgba(236, 72, 153, 0.2); border: 1px solid #ec4899; color: #ec4899; padding: 4px 8px; border-radius: 6px;">√ = Signo Radical</span>
              <span style="background: rgba(16, 185, 129, 0.2); border: 1px solid #10b981; color: #10b981; padding: 4px 8px; border-radius: 6px;">16 = Radicando</span>
              <span style="background: rgba(253, 224, 71, 0.2); border: 1px solid #fde047; color: #fde047; padding: 4px 8px; border-radius: 6px;">6 = Raíz final (3×2)</span>
            </div>
          </div>
        `;
      }
      if (sec.commonErrors) {
        extra += `
          <div class="common-errors-box">
            <div style="font-weight: 700; color: #f87171; margin-bottom: 0.5rem; display: flex; align-items: center; gap: 0.4rem;">
              ⚠️ ¡Cuidado con las Trampas! Errores Comunes
            </div>
            ${sec.commonErrors.map(err => `
              <div class="error-item">
                <div class="error-bad">❌ ${MathRenderer.render(err.error)}</div>
                <div class="error-fix">✅ Corrección: ${MathRenderer.render(err.fix)}</div>
              </div>
            `).join("")}
          </div>
        `;
      }
      if (sec.example) {
        extra += `
          <div class="step-by-step-box">
            <div style="font-weight: 700; color: #34d399; margin-bottom: 0.75rem; font-size: 1.05rem;">
              📝 Ejemplo Resuelto Paso a Paso: <span style="color:#fff;">${MathRenderer.renderFormula(sec.example.problem)}</span>
            </div>
            ${sec.example.steps.map((st, i) => `
              <div class="step-item">
                <div class="step-num">${i + 1}</div>
                <div>${MathRenderer.render(st)}</div>
              </div>
            `).join("")}
          </div>
        `;
      }

      sectionsHTML += `
        <div class="lesson-section-card">
          <h3>${sec.title}</h3>
          <div class="lesson-text">${MathRenderer.render(sec.content)}</div>
          ${extra}
        </div>
      `;
    });

    container.innerHTML = `
      <div class="lesson-header-card">
        <div class="lesson-realm-icon">${realm.icon}</div>
        <div>
          <div style="font-size:0.85rem; color: #a78bfa; font-weight:700; text-transform:uppercase;">Reino ${realm.id} · Grimorio de Aprendizaje</div>
          <h2 style="font-size: 1.8rem; color: #fff; margin-bottom: 0.25rem;">${realm.title}</h2>
          <div style="color: #f59e0b; font-weight: 600;">${realm.subtitle}</div>
          <p style="color: #cbd5e1; font-size: 0.95rem; margin-top: 0.5rem;">${realm.lesson.intro}</p>
        </div>
      </div>

      ${sectionsHTML}

      <div style="display: flex; gap: 1rem; justify-content: space-between; margin-top: 2rem; margin-bottom: 3rem;">
        <button id="btn-lesson-back-map" class="btn-hero btn-hero-secondary">
          🗺️ Volver al Mapa
        </button>
        <button id="btn-lesson-go-battle" class="btn-hero btn-hero-primary">
          ⚔️ Ir al Desafío del Reino
        </button>
      </div>
    `;

    document.getElementById("btn-lesson-back-map")?.addEventListener("click", () => {
      if (window.soundManager) window.soundManager.playClick();
      this.showScreen("map");
    });

    document.getElementById("btn-lesson-go-battle")?.addEventListener("click", () => {
      if (window.soundManager) window.soundManager.playClick();
      this.startRealmBattle(realm.id);
    });

    this.showScreen("learn");
  }

  // ========================================================================
  // SISTEMA DE COMBATE RPG / EVALUACIÓN DEL REINO
  // ========================================================================
  startRealmBattle(realmId) {
    const realm = RADICAL_QUEST_DATA.realms.find(r => r.id === realmId);
    if (!realm) return;

    this.isFinalExam = false;
    this.currentRealm = realm;
    this.currentBattle = {
      realmId: realm.id,
      questions: [...realm.questions],
      currentIndex: 0,
      score: 0,
      correctCount: 0,
      wrongCount: 0,
      mistakes: [],
      heroMaxHP: 100,
      heroHP: 100,
      bossMaxHP: realm.boss.hp,
      bossHP: realm.boss.hp,
      damagePerQuestion: Math.ceil(realm.boss.hp / realm.questions.length)
    };

    this.renderBattleScreen();
    this.showScreen("battle");
  }

  startFinalExam() {
    this.isFinalExam = true;
    const exam = RADICAL_QUEST_DATA.finalExam;
    this.currentBattle = {
      realmId: 999,
      questions: [...exam.questions],
      currentIndex: 0,
      score: 0,
      correctCount: 0,
      wrongCount: 0,
      mistakes: [],
      heroMaxHP: 100,
      heroHP: 100,
      bossMaxHP: exam.boss.hp,
      bossHP: exam.boss.hp,
      damagePerQuestion: Math.ceil(exam.boss.hp / exam.questions.length)
    };

    this.renderBattleScreen();
    this.showScreen("battle");
  }

  renderBattleScreen() {
    const battle = this.currentBattle;
    const q = battle.questions[battle.currentIndex];
    const isBoss = this.isFinalExam ? RADICAL_QUEST_DATA.finalExam.boss : this.currentRealm.boss;

    const stageEl = document.getElementById("battle-stage-container");
    if (!stageEl) return;

    // Calcular porcentajes de vida
    const heroHpPct = Math.max(0, Math.min(100, (battle.heroHP / battle.heroMaxHP) * 100));
    const bossHpPct = Math.max(0, Math.min(100, (battle.bossHP / battle.bossMaxHP) * 100));

    stageEl.innerHTML = `
      <!-- Combatiente Héroe -->
      <div class="combatant-card">
        <div id="battle-hero-avatar" class="combatant-avatar">
          ${window.gameState.state.hero.avatar}
        </div>
        <div class="combatant-name">${window.gameState.state.hero.name}</div>
        <div class="hp-bar-container">
          <div class="hp-bar-fill" style="width: ${heroHpPct}%;"></div>
          <span class="hp-text">${battle.heroHP} / ${battle.heroMaxHP} HP</span>
        </div>
      </div>

      <!-- VS Banner -->
      <div class="battle-versus">VS</div>

      <!-- Combatiente Jefe -->
      <div class="combatant-card">
        <div id="battle-boss-avatar" class="combatant-avatar">
          ${isBoss.avatar}
        </div>
        <div class="combatant-name">${isBoss.name}</div>
        <div class="hp-bar-container">
          <div class="hp-bar-fill boss-hp" style="width: ${bossHpPct}%;"></div>
          <span class="hp-text">${battle.bossHP} / ${battle.bossMaxHP} HP</span>
        </div>
      </div>
    `;

    // Renderizar Pregunta y Opciones
    const cardEl = document.getElementById("battle-challenge-container");
    if (!cardEl) return;

    let inputAreaHTML = "";
    if (q.type === "choice" || !q.type) {
      inputAreaHTML = `
        <div class="options-grid">
          ${q.options.map((opt, idx) => `
            <button class="option-btn" data-option-idx="${idx}">
              <span class="option-letter">${String.fromCharCode(65 + idx)}</span>
              <span>${MathRenderer.render(opt)}</span>
            </button>
          `).join("")}
        </div>
      `;
    } else if (q.type === "input") {
      inputAreaHTML = `
        <div class="input-answer-container">
          <div class="math-input-box">
            <input type="text" id="interactive-math-input" class="math-input-field" placeholder="${q.placeholder || 'Escribe tu respuesta'}" autofocus />
            <button id="btn-submit-text-answer" class="btn-submit-answer">Lanzar Hechizo ✨</button>
          </div>
          <div class="virtual-keypad">
            <button class="keypad-btn" data-insert="√">√</button>
            <button class="keypad-btn" data-insert="²">²</button>
            <button class="keypad-btn" data-insert="³">³</button>
            <button class="keypad-btn" data-insert="/">/</button>
            <button class="keypad-btn" data-insert="+">+</button>
            <button class="keypad-btn" data-insert="-">-</button>
            <button class="keypad-btn" data-insert="x">x</button>
            <button class="keypad-btn" data-insert="y">y</button>
            <button class="keypad-btn" data-insert="(">(</button>
            <button class="keypad-btn" data-insert=")">)</button>
          </div>
        </div>
      `;
    }

    cardEl.innerHTML = `
      <div class="challenge-question-num">
        <span>Pregunta ${battle.currentIndex + 1} de ${battle.questions.length}</span>
        <span>Aciertos: ${battle.correctCount} / ${battle.currentIndex}</span>
      </div>
      <div class="challenge-prompt">
        ${MathRenderer.render(q.question)}
      </div>
      ${inputAreaHTML}
      <div id="battle-turn-feedback-slot"></div>
    `;

    // Vincular eventos de selección
    if (q.type === "choice" || !q.type) {
      cardEl.querySelectorAll(".option-btn").forEach(btn => {
        btn.addEventListener("click", (e) => {
          const selectedIdx = parseInt(btn.dataset.optionIdx);
          this.handleTurnAnswer(selectedIdx, btn);
        });
      });
    } else if (q.type === "input") {
      const inputEl = document.getElementById("interactive-math-input");
      const submitBtn = document.getElementById("btn-submit-text-answer");

      cardEl.querySelectorAll(".keypad-btn").forEach(kBtn => {
        kBtn.addEventListener("click", () => {
          if (inputEl) {
            inputEl.value += kBtn.dataset.insert;
            inputEl.focus();
          }
        });
      });

      submitBtn?.addEventListener("click", () => {
        if (!inputEl) return;
        this.handleTurnAnswer(inputEl.value.trim());
      });

      inputEl?.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          this.handleTurnAnswer(inputEl.value.trim());
        }
      });
    }
  }

  handleTurnAnswer(userAnswer, optionBtnElement = null) {
    const battle = this.currentBattle;
    const q = battle.questions[battle.currentIndex];
    const feedbackSlot = document.getElementById("battle-turn-feedback-slot");

    // Desactivar botones de respuesta para evitar doble clic
    document.querySelectorAll(".option-btn, .btn-submit-answer").forEach(b => b.disabled = true);

    let isCorrect = false;

    if (q.type === "choice" || !q.type) {
      isCorrect = (userAnswer === q.correct);
      if (optionBtnElement) {
        optionBtnElement.classList.add(isCorrect ? "selected-correct" : "selected-wrong");
      }
    } else if (q.type === "input") {
      const cleanUser = String(userAnswer).replace(/\s+/g, "").toLowerCase();
      isCorrect = q.acceptedAnswers.some(ans => {
        const cleanAns = String(ans).replace(/\s+/g, "").toLowerCase();
        return cleanUser === cleanAns;
      });
    }

    const heroAvatar = document.getElementById("battle-hero-avatar");
    const bossAvatar = document.getElementById("battle-boss-avatar");

    if (isCorrect) {
      if (window.soundManager) {
        window.soundManager.playAttack();
        setTimeout(() => window.soundManager.playCorrect(), 200);
      }

      battle.score += 100;
      battle.correctCount++;
      battle.bossHP = Math.max(0, battle.bossHP - battle.damagePerQuestion);

      if (bossAvatar) {
        bossAvatar.classList.add("shake-anim");
        setTimeout(() => bossAvatar.classList.remove("shake-anim"), 500);
      }

      feedbackSlot.innerHTML = `
        <div class="turn-feedback-card correct">
          <div class="turn-feedback-title">✨ ¡Impacto Crítico Mágico! ¡Respuesta Correcta!</div>
          <div class="turn-feedback-desc">${MathRenderer.render(q.explanation)}</div>
          <button id="btn-next-turn" class="btn-next-turn">Continuar Desafío ➔</button>
        </div>
      `;
    } else {
      if (window.soundManager) window.soundManager.playWrong();

      battle.wrongCount++;
      battle.mistakes.push({
        question: q.question,
        userAnswer: userAnswer,
        correctAnswer: (q.type === "choice" || !q.type) ? q.options[q.correct] : q.acceptedAnswers[0],
        explanation: q.explanation
      });

      // Monstruo contraataca
      const damageToHero = Math.ceil(battle.heroMaxHP / (battle.questions.length + 1));
      battle.heroHP = Math.max(0, battle.heroHP - damageToHero);

      if (heroAvatar) {
        heroAvatar.classList.add("shake-anim");
        setTimeout(() => heroAvatar.classList.remove("shake-anim"), 500);
      }

      feedbackSlot.innerHTML = `
        <div class="turn-feedback-card wrong">
          <div class="turn-feedback-title">💥 ¡El Monstruo ha Bloqueado tu Hechizo y Contraataca!</div>
          <div class="turn-feedback-desc">
            <strong>Explicación Didáctica:</strong><br/>
            ${MathRenderer.render(q.explanation)}
          </div>
          <button id="btn-next-turn" class="btn-next-turn">Continuar Desafío ➔</button>
        </div>
      `;
    }

    document.getElementById("btn-next-turn")?.addEventListener("click", () => {
      battle.currentIndex++;
      if (battle.currentIndex < battle.questions.length && battle.heroHP > 0) {
        this.renderBattleScreen();
      } else {
        this.finishBattle();
      }
    });
  }

  finishBattle() {
    const battle = this.currentBattle;
    const totalQ = battle.questions.length;
    const pct = Math.round((battle.correctCount / totalQ) * 100);
    const passed = pct >= 60;

    let stars = 0;
    if (pct >= 90) stars = 3;
    else if (pct >= 75) stars = 2;
    else if (pct >= 60) stars = 1;

    // Actualizar recompensas
    const xpEarned = battle.correctCount * 30 + (passed ? 100 : 20);
    const goldEarned = battle.correctCount * 15 + (passed ? 50 : 10);

    window.gameState.addXP(xpEarned);
    window.gameState.addGold(goldEarned);

    if (passed && !this.isFinalExam) {
      // Guardar estrellas
      const prevStars = window.gameState.state.realmStars[battle.realmId] || 0;
      if (stars > prevStars) {
        window.gameState.state.realmStars[battle.realmId] = stars;
      }
      // Desbloquear siguiente reino
      if (battle.realmId < 7) {
        window.gameState.unlockRealm(battle.realmId + 1);
      }
      // Insignia del reino
      window.gameState.unlockAchievement(`ach_realm${battle.realmId}`);
    }

    if (this.isFinalExam && pct >= 80) {
      window.gameState.unlockAchievement("ach_crown");
    }

    window.gameState.save();
    if (window.soundManager) window.soundManager.playLevelClear();

    // Renderizar resultados
    const resultsContainer = document.getElementById("results-card-container");
    if (!resultsContainer) return;

    resultsContainer.innerHTML = `
      <div class="results-card">
        <div class="results-icon">${passed ? "🏆" : "💀"}</div>
        <h2 style="font-size: 2rem; color: #fff; margin-bottom: 0.5rem;">
          ${passed ? "¡Victoria Legendaria!" : "¡Derrota Temporal!"}
        </h2>
        <div style="font-size: 1.1rem; color: #f59e0b; font-weight: 700; margin-bottom: 1rem;">
          ${passed ? (this.isFinalExam ? "¡Has Dominado el Gran Examen Final!" : `¡Reino ${battle.realmId} Conquistado!`) : "El enemigo fue implacable. ¡Repasa la lección y vuelve a intentarlo!"}
        </div>

        <div class="results-score-circle">
          <span class="results-score-num">${pct}%</span>
          <span class="results-score-label">Dominio</span>
        </div>

        <div style="font-size: 1.8rem; margin-bottom: 1rem;">
          ${"⭐".repeat(stars) + "☆".repeat(3 - stars)}
        </div>

        <div class="results-breakdown">
          <div>
            <div style="color: #94a3b8; font-size: 0.8rem;">Aciertos</div>
            <div style="color: #10b981; font-weight: 800; font-size: 1.2rem;">${battle.correctCount} / ${totalQ}</div>
          </div>
          <div>
            <div style="color: #94a3b8; font-size: 0.8rem;">Recompensas</div>
            <div style="color: #f59e0b; font-weight: 800; font-size: 1.2rem;">+${xpEarned} XP · +${goldEarned} 🪙</div>
          </div>
        </div>

        ${battle.mistakes.length > 0 ? `
          <div style="margin: 1.5rem 0; text-align: left; background: rgba(15, 23, 42, 0.7); padding: 1rem; border-radius: 12px; border: 1px solid rgba(239, 68, 68, 0.3);">
            <div style="font-weight: 700; color: #f87171; margin-bottom: 0.75rem;">🔍 Revisión de Errores Comunes en tu Prueba:</div>
            ${battle.mistakes.map(m => `
              <div style="font-size: 0.85rem; margin-bottom: 0.75rem; border-bottom: 1px dashed rgba(255,255,255,0.1); padding-bottom: 0.5rem;">
                <div style="color: #fff; font-weight: 600;">${MathRenderer.render(m.question)}</div>
                <div style="color: #34d399; margin-top: 2px;">✅ Respuesta correcta: ${MathRenderer.render(String(m.correctAnswer))}</div>
                <div style="color: #94a3b8; margin-top: 2px;">💡 ${MathRenderer.render(m.explanation)}</div>
              </div>
            `).join("")}
          </div>
        ` : `
          <div style="background: rgba(16, 185, 129, 0.15); border: 1px solid #10b981; padding: 1rem; border-radius: 12px; margin: 1.5rem 0; color: #34d399; font-weight: 600;">
            🌟 ¡PUNTUACIÓN PERFECTA! Ningún error cometido en este desafío.
          </div>
        `}

        ${(this.isFinalExam && pct >= 80) ? `
          <div style="background: linear-gradient(135deg, rgba(245, 158, 11, 0.2), rgba(139, 92, 246, 0.2)); border: 2px solid #f59e0b; border-radius: 16px; padding: 1.5rem; margin-bottom: 1.5rem;">
            <div style="font-size: 2rem;">📜👑</div>
            <h3 style="color: #fde047; font-size: 1.3rem;">DIPLOMA DE MAESTRO SUPREMO</h3>
            <p style="color: #e2e8f0; font-size: 0.95rem; margin: 0.5rem 0;">
              Por haber completado y dominado con ${pct}% de maestría todos los reinos y el Gran Examen Final de los Radicales Matemáticos.
            </p>
            <div style="font-weight: 800; color: #fff; font-size: 1.1rem; margin-top: 0.5rem;">
              Otorgado a: ${window.gameState.state.hero.name}
            </div>
          </div>
        ` : ""}

        <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
          <button id="btn-results-map" class="btn-hero btn-hero-secondary">
            🗺️ Volver al Mapa
          </button>
          <button id="btn-results-retry" class="btn-hero btn-hero-primary">
            🔄 Repetir Prueba
          </button>
        </div>
      </div>
    `;

    document.getElementById("btn-results-map")?.addEventListener("click", () => {
      this.renderWorldMap();
      this.showScreen("map");
    });

    document.getElementById("btn-results-retry")?.addEventListener("click", () => {
      if (this.isFinalExam) this.startFinalExam();
      else this.startRealmBattle(battle.realmId);
    });

    this.showScreen("results");
  }

  // ========================================================================
  // MODO CONTRARRELOJ (TORBELLINO RADICAL)
  // ========================================================================
  startSpeedRush() {
    this.speedTimeLeft = 60;
    this.speedScore = 0;
    this.speedStreak = 0;

    // Recolectar todas las preguntas rápidas de los 7 reinos
    const pool = [];
    RADICAL_QUEST_DATA.realms.forEach(r => pool.push(...r.questions));
    this.speedPool = pool.sort(() => Math.random() - 0.5);
    this.speedIndex = 0;

    this.showScreen("speed");
    this.nextSpeedQuestion();

    if (this.speedTimer) clearInterval(this.speedTimer);
    this.speedTimer = setInterval(() => {
      this.speedTimeLeft--;
      const timerEl = document.getElementById("speed-timer-readout");
      if (timerEl) timerEl.textContent = `${this.speedTimeLeft}s`;

      if (this.speedTimeLeft <= 0) {
        clearInterval(this.speedTimer);
        this.finishSpeedRush();
      }
    }, 1000);
  }

  nextSpeedQuestion() {
    if (this.speedIndex >= this.speedPool.length) {
      this.speedIndex = 0;
      this.speedPool.sort(() => Math.random() - 0.5);
    }
    const q = this.speedPool[this.speedIndex];
    const container = document.getElementById("speed-question-card");
    if (!container) return;

    container.innerHTML = `
      <div style="font-size: 1.4rem; font-weight: 700; color: #fff; margin-bottom: 1.5rem; text-align: center;">
        ${MathRenderer.render(q.question)}
      </div>
      <div class="options-grid">
        ${(q.options || ["Opción 1", "Opción 2", "Opción 3", "Opción 4"]).map((opt, i) => `
          <button class="option-btn speed-opt-btn" data-opt-idx="${i}">
            <span class="option-letter">${String.fromCharCode(65 + i)}</span>
            <span>${MathRenderer.render(opt)}</span>
          </button>
        `).join("")}
      </div>
    `;

    container.querySelectorAll(".speed-opt-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const sel = parseInt(btn.dataset.optIdx);
        const correct = (q.type === "choice" || !q.type) ? (sel === q.correct) : (sel === 0);

        if (correct) {
          if (window.soundManager) window.soundManager.playCorrect();
          this.speedScore += 10 * (1 + Math.floor(this.speedStreak / 3));
          this.speedStreak++;
          if (this.speedStreak >= 5) {
            window.gameState.unlockAchievement("ach_speed");
          }
        } else {
          if (window.soundManager) window.soundManager.playWrong();
          this.speedStreak = 0;
        }

        const scoreEl = document.getElementById("speed-score-readout");
        const comboEl = document.getElementById("speed-combo-readout");
        if (scoreEl) scoreEl.textContent = this.speedScore;
        if (comboEl) comboEl.textContent = `Combo x${1 + Math.floor(this.speedStreak / 3)}`;

        this.speedIndex++;
        this.nextSpeedQuestion();
      });
    });
  }

  finishSpeedRush() {
    if (this.speedScore > window.gameState.state.speedHighscore) {
      window.gameState.state.speedHighscore = this.speedScore;
      window.gameState.save();
    }
    window.gameState.addGold(Math.floor(this.speedScore / 2));
    window.gameState.addXP(this.speedScore);

    alert(`⏱️ ¡Tiempo agotado!\nPuntuación final en el Torbellino: ${this.speedScore} puntos.\nRecompensa: +${this.speedScore} XP y +${Math.floor(this.speedScore / 2)} Monedas de oro.`);
    this.showScreen("map");
  }

  // ========================================================================
  // CÓDICE DE FÓRMULAS
  // ========================================================================
  renderCodex() {
    const container = document.getElementById("codex-categories-container");
    if (!container) return;
    container.innerHTML = "";

    RADICAL_QUEST_DATA.formulasCodex.forEach(cat => {
      const catDiv = document.createElement("div");
      catDiv.className = "formula-category";
      catDiv.innerHTML = `
        <div class="formula-category-title">
          <span>📜</span>
          <span>${cat.category}</span>
        </div>
        <div class="formulas-grid">
          ${cat.items.map(item => `
            <div class="formula-card">
              <div class="formula-name">${item.name}</div>
              <div class="formula-display">${MathRenderer.renderFormula(item.formula)}</div>
              <div class="formula-desc">${item.desc}</div>
            </div>
          `).join("")}
        </div>
      `;
      container.appendChild(catDiv);
    });

    window.gameState.unlockAchievement("ach_scholar");
  }

  filterCodex(query) {
    const q = query.toLowerCase().trim();
    document.querySelectorAll(".formula-card").forEach(card => {
      const text = card.textContent.toLowerCase();
      card.style.display = text.includes(q) ? "flex" : "none";
    });
  }

  // ========================================================================
  // INSIGNIAS Y LOGROS
  // ========================================================================
  renderAchievements() {
    const container = document.getElementById("achievements-grid-container");
    if (!container) return;
    container.innerHTML = "";

    const userAch = window.gameState.state.achievements;

    RADICAL_QUEST_DATA.achievements.forEach(ach => {
      const isUnlocked = userAch.includes(ach.id);
      const card = document.createElement("div");
      card.className = `achievement-card ${isUnlocked ? "unlocked" : ""}`;
      card.innerHTML = `
        <div class="achievement-icon" style="${isUnlocked ? "" : "filter: grayscale(1); opacity: 0.5;"}">${ach.icon}</div>
        <div>
          <div style="font-weight: 700; color: ${isUnlocked ? "#fde047" : "#94a3b8"}; font-size: 0.95rem;">
            ${ach.title}
          </div>
          <div style="font-size: 0.8rem; color: #cbd5e1; margin-top: 2px;">
            ${ach.desc}
          </div>
          <div style="font-size: 0.7rem; color: ${isUnlocked ? "#34d399" : "#64748b"}; font-weight: 700; margin-top: 4px;">
            ${isUnlocked ? "✓ DESBLOQUEADO" : "🔒 BLOQUEADO"}
          </div>
        </div>
      `;
      container.appendChild(card);
    });
  }

  // Fondo animado de estrellas y partículas matemáticas en Canvas
  initCanvasBackground() {
    const canvas = document.getElementById("bg-canvas");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");

    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    window.addEventListener("resize", () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    });

    const particles = [];
    const symbols = ["√", "∛", "x²", "a/b", "π", "n√", "∑", "∞", "λ"];

    for (let i = 0; i < 35; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.4,
        vy: -0.2 - Math.random() * 0.5,
        symbol: symbols[Math.floor(Math.random() * symbols.length)],
        size: 14 + Math.random() * 18,
        alpha: 0.1 + Math.random() * 0.3
      });
    }

    const animate = () => {
      ctx.clearRect(0, 0, width, height);

      particles.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;

        if (p.y < -50) p.y = height + 50;
        if (p.x < -50) p.x = width + 50;
        if (p.x > width + 50) p.x = -50;

        ctx.font = `${p.size}px serif`;
        ctx.fillStyle = `rgba(167, 139, 250, ${p.alpha})`;
        ctx.fillText(p.symbol, p.x, p.y);
      });

      requestAnimationFrame(animate);
    };

    animate();
  }
}

// Inicialización automática
window.addEventListener("DOMContentLoaded", () => {
  window.radicalQuestApp = new RadicalQuestApp();
});
