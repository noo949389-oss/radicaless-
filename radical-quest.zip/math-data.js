// ==========================================================================
// RADICAL QUEST: DOMINA EL PODER DE LAS RAÍCES
// Base de Datos Educativa y Banco de Preguntas / Desafíos
// ==========================================================================

const RADICAL_QUEST_DATA = {
  // Configuración de los 7 Reinos
  realms: [
    {
      id: 1,
      title: "El Bosque del Origen",
      subtitle: "¿Qué son los Radicales?",
      icon: "🌱",
      color: "#10b981",
      darkColor: "#064e3b",
      bgGradient: "from-emerald-950 via-teal-900 to-slate-900",
      boss: {
        name: "Gólem del Subradical",
        title: "Guardián de las Raíces Primordiales",
        hp: 100,
        avatar: "🗿",
        dialogue: "¡Nadie cruza el Bosque sin conocer las entrañas de los radicales! ¡Demuestra de qué están hechos!"
      },
      lesson: {
        intro: "Bienvenido, joven aprendiz. Antes de empuñar la magia de las matemáticas, debes entender de dónde nacen las raíces.",
        sections: [
          {
            title: "1. ¿Qué es una Raíz y un Radical?",
            content: `Un **radical** es la expresión matemática que indica la operación de **extracción de la raíz**.
            
La radicación es la **operación inversa a la potenciación**. Si elevar un número al cuadrado significa multiplicarlo por sí mismo ($5^2 = 25$), la raíz cuadrada busca el camino de regreso: encontrar qué número multiplicado por sí mismo da como resultado $25$.

$$\\text{Si } b^n = a \\implies \\sqrt[n]{a} = b$$

**Ejemplo:** Como $3^2 = 9$, entonces la raíz cuadrada de $9$ es $\\sqrt{9} = 3$.`,
            formula: "\\sqrt[n]{a} = b \\iff b^n = a"
          },
          {
            title: "2. ¿Para qué sirven los Radicales en la Vida Real?",
            content: `Los radicales no son solo números en un papel; son las leyes que rigen el mundo físico:
            
* **Geometría y Construcción:** Si conoces el área de una plaza cuadrada ($144\\text{ m}^2$), el lado de la plaza mide exactamente $\\sqrt{144} = 12\\text{ metros}$.
* **Teorema de Pitágoras:** Para calcular la hipotenusa de un triángulo o la distancia más corta entre dos puntos en un mapa GPS: $c = \\sqrt{a^2 + b^2}$.
* **Física y Caída Libre:** La velocidad de un objeto al caer desde una altura $h$ es $v = \\sqrt{2gh}$.
* **Exactitud Científica:** Hay números como la diagonal de un cuadrado de lado $1$, que mide $\\sqrt{2} = 1.4142135...$ ¡Un número con infinitos decimales! Expresarlo como $\\sqrt{2}$ es la única forma de no perder jamás la precisión.`
          },
          {
            title: "3. Anatomía de un Radical: Las 4 Partes Sagradas",
            content: `Observa detenidamente la estructura de un radical:
            
* **Signo Radical ($\\sqrt{\\phantom{x}}$):** El símbolo especial que ordena buscar la raíz. Proviene de la letra 'r' estilizada de la palabra latina *radix* (raíz), introducida por el matemático Christoph Rudolff en 1525.
* **Índice ($n$):** El número pequeño ubicado arriba a la izquierda. Indica cuántas veces debe multiplicarse la raíz por sí misma para obtener el radicando. **¡Regla de Oro!** Si el índice no está escrito, **siempre vale 2** (raíz cuadrada).
* **Radicando o Subradical ($a$):** El número o expresión que se encuentra dentro del signo radical. Es la cantidad a la que le aplicamos la raíz.
* **Raíz ($b$):** El resultado obtenido de la operación.
* **Coeficiente ($c$):** Si hay un número afuera multiplicando a toda la raíz (ej: $5\\sqrt{3}$), ese número es el coeficiente.`,
            interactiveDiagram: true
          },
          {
            title: "4. ¡Cuidado! Errores Comunes de Principiante",
            commonErrors: [
              {
                error: "Creer que si no hay índice, el índice vale 0 o 1.",
                fix: "Por convención universal, un radical sin índice escrito $\\sqrt{x}$ tiene índice **2** (raíz cuadrada)."
              },
              {
                error: "Confundir Coeficiente con Índice: pensar que $3\\sqrt{8}$ es igual a $\\sqrt[3]{8}$.",
                fix: "$3\\sqrt{8}$ significa $3$ multiplicado por la raíz cuadrada de $8$ ($3 \\times 2.828 \\approx 8.48$), mientras que $\\sqrt[3]{8}$ es la raíz cúbica de $8$, que es exactamente $2$."
              },
              {
                error: "Creer que $\\sqrt{a + b} = \\sqrt{a} + \\sqrt{b}$.",
                fix: "¡FALSO! Comprobación: $\\sqrt{9 + 16} = \\sqrt{25} = 5$. Pero $\\sqrt{9} + \\sqrt{16} = 3 + 4 = 7$. ¡$5 \\neq 7$! La raíz **nunca** se puede separar sobre una suma o resta."
              }
            ]
          },
          {
            title: "5. Ejemplo Guiado Paso a Paso",
            example: {
              problem: "Identifica las partes y calcula la raíz de: 4\\sqrt{81}",
              steps: [
                "Paso 1: Identifica el coeficiente exterior: El número multiplicador es 4.",
                "Paso 2: Identifica el índice: No tiene número escrito, por lo tanto el índice es 2 (raíz cuadrada).",
                "Paso 3: Identifica el radicando: El número dentro de la raíz es 81.",
                "Paso 4: Calcula la raíz de 81: Buscamos un número que elevado al cuadrado dé 81. Como 9 × 9 = 81, la raíz es 9.",
                "Paso 5: Multiplica por el coeficiente: 4 × 9 = 36.",
                "Resultado final: 4\\sqrt{81} = 36."
              ]
            }
          }
        ]
      },
      questions: [
        {
          id: "q1_1",
          type: "choice",
          question: "¿Cómo se llama el número o expresión que se encuentra dentro del símbolo radical?",
          options: ["Índice", "Radicando o subradical", "Coeficiente", "Potencia"],
          correct: 1,
          explanation: "El radicando (o cantidad subradical) es el número o expresión algebraica que está protegido bajo el símbolo de la raíz."
        },
        {
          id: "q1_2",
          type: "choice",
          question: "Si un radical está escrito simplemente como $\\sqrt{49}$ sin ningún número en la esquina superior izquierda, ¿cuál es su índice?",
          options: ["0", "1", "2", "No tiene índice"],
          correct: 2,
          explanation: "Por convención en álgebra, cuando no se escribe el índice en un radical, se entiende que es 2 (raíz cuadrada)."
        },
        {
          id: "q1_3",
          type: "choice",
          question: "¿Cuál es la diferencia matemática entre $4\\sqrt{25}$ y $\\sqrt[4]{25}$?",
          options: [
            "Son exactamente lo mismo escrito de dos formas.",
            "En $4\\sqrt{25}$, el 4 es un coeficiente que multiplica; en $\\sqrt[4]{25}$, el 4 es el índice de la raíz.",
            "En $4\\sqrt{25}$ el 4 se suma al 25.",
            "En $\\sqrt[4]{25}$ se multiplica 4 por 25."
          ],
          correct: 1,
          explanation: "El número a la izquierda en tamaño normal es el coeficiente exterior. El número pequeño en la 'V' del radical es el índice de la raíz."
        },
        {
          id: "q1_4",
          type: "input",
          question: "Calcula el valor numérico de la expresión: $3\\sqrt{64}$",
          placeholder: "Escribe tu respuesta numérica",
          acceptedAnswers: ["24"],
          explanation: "Primero calculamos la raíz: $\\sqrt{64} = 8$ (porque $8^2 = 64$). Luego multiplicamos por el coeficiente: $3 \\times 8 = 24$."
        },
        {
          id: "q1_5",
          type: "choice",
          question: "¿Cuál de las siguientes afirmaciones es CORRECTA?",
          options: [
            "$\\sqrt{9 + 16} = \\sqrt{9} + \\sqrt{16}$",
            "La radicación es la operación inversa de la potenciación.",
            "La raíz cuadrada de un número siempre es igual a la mitad de ese número.",
            "El símbolo $\\sqrt{\\phantom{x}}$ fue inventado por Isaac Newton en 1900."
          ],
          correct: 1,
          explanation: "La radicación es la operación inversa de la potenciación. Recuerda que la raíz cuadrada NO es dividir entre dos (ej: $\\sqrt{16} = 4$, no 8) y no se distribuye en la suma."
        },
        {
          id: "q1_6",
          type: "input",
          question: "¿Cuál es el radicando de la expresión radical $7\\sqrt[5]{32}$?",
          placeholder: "Escribe solo el número del radicando",
          acceptedAnswers: ["32"],
          explanation: "En $7\\sqrt[5]{32}$, el coeficiente es 7, el índice es 5 y el radicando (lo que está adentro) es 32."
        }
      ]
    },

    {
      id: 2,
      title: "Las Cavernas del Índice",
      subtitle: "Tipos de Raíces y Exactitud",
      icon: "💎",
      color: "#06b6d4",
      darkColor: "#164e63",
      bgGradient: "from-cyan-950 via-sky-900 to-slate-900",
      boss: {
        name: "Basilisco de los Índices",
        title: "Monstruo de los Cristales Cúbicos",
        hp: 120,
        avatar: "🐉",
        dialogue: "¡Crees que toda raíz es cuadrada! Mis gemas tienen 3, 4 y 5 dimensiones. ¡Resiste mi aliento polar!"
      },
      lesson: {
        intro: "En las profundidades de estas cavernas, los índices aumentan. Aprenderás a dominar raíces cúbicas, cuartas, quintas y a distinguir lo exacto de lo irracional.",
        sections: [
          {
            title: "1. Raíz Cuadrada ($n = 2$)",
            content: `Busca un número que al multiplicarse por sí mismo **2 veces** dé el radicando:
* $\\sqrt{4} = 2$ porque $2 \\times 2 = 4$.
* $\\sqrt{25} = 5$ porque $5^2 = 25$.
* $\\sqrt{100} = 10$ porque $10^2 = 100$.`,
            formula: "\\sqrt{x} = y \\iff y^2 = x"
          },
          {
            title: "2. Raíz Cúbica ($n = 3$) ¡La Puerta de los Negativos!",
            content: `Busca un número que al multiplicarse por sí mismo **3 veces** dé el radicando:
* $\\sqrt[3]{8} = 2$ porque $2 \\times 2 \\times 2 = 8$.
* $\\sqrt[3]{27} = 3$ porque $3^3 = 27$.
* $\\sqrt[3]{125} = 5$ porque $5^3 = 125$.

**¡Gran Descubrimiento!**
¿Existe la raíz de un número negativo?
* En raíces cuadradas: $\\sqrt{-9}$ **NO tiene solución real** (porque ningún número real al cuadrado da negativo: $(+3)^2 = 9$ y $(-3)^2 = 9$).
* En raíces CÚBICAS: $\\sqrt[3]{-8} = -2$ **¡SÍ EXISTE!** Porque $(-2) \\times (-2) \\times (-2) = -8$.
* **Regla Universal:** Las raíces con **índice impar** de números negativos **siempre tienen resultado real y es negativo**.`,
            formula: "\\sqrt[3]{-a} = -\\sqrt[3]{a}"
          },
          {
            title: "3. Raíces de Orden Superior ($n = 4, 5, 6...$)",
            content: `* **Raíz Cuarta ($n = 4$):** $\\sqrt[4]{16} = 2$ porque $2^4 = 2 \\times 2 \\times 2 \\times 2 = 16$.
* **Raíz Quinta ($n = 5$):** $\\sqrt[5]{32} = 2$ porque $2^5 = 32$. Y $\\sqrt[5]{-243} = -3$ porque $(-3)^5 = -243$.`
          },
          {
            title: "4. Raíces Exactas vs. Raíces No Exactas (Irracionales)",
            content: `* **Raíces Exactas:** El resultado es un número entero o racional. Los radicandos son potencias perfectas (ej: $1, 4, 9, 16, 25, 36, 49, 64, 81, 100...$).
  $$\\sqrt{49} = 7, \\quad \\sqrt[3]{64} = 4, \\quad \\sqrt{\\frac{9}{25}} = \\frac{3}{5}$$
* **Raíces No Exactas:** Producen **números irracionales**, con decimales infinitos que jamás se repiten de forma periódica:
  $$\\sqrt{2} = 1.41421356..., \\quad \\sqrt{3} = 1.7320508..., \\quad \\sqrt{5} = 2.2360679...$$
  En álgebra, nunca las convertimos a decimal aproximado; las dejamos escritas como radicales para conservar el 100% de la precisión.`
          },
          {
            title: "5. Ejemplo Guiado",
            example: {
              problem: "Resuelve: \\sqrt[3]{-64} + \\sqrt[4]{81}",
              steps: [
                "Paso 1: Analiza la primera raíz \\sqrt[3]{-64}. El índice es 3 (impar), por lo que admite negativos.",
                "Paso 2: Buscamos un número que al cubo dé -64. (-4) × (-4) × (-4) = -64. Así, \\sqrt[3]{-64} = -4.",
                "Paso 3: Analiza la segunda raíz \\sqrt[4]{81}. El índice es 4. Buscamos un número positivo que a la cuarta dé 81: 3 × 3 × 3 × 3 = 81. Así, \\sqrt[4]{81} = 3.",
                "Paso 4: Realiza la suma: (-4) + 3 = -1.",
                "Resultado final: -1."
              ]
            }
          }
        ]
      },
      questions: [
        {
          id: "q2_1",
          type: "choice",
          question: "¿Cuál es el valor de $\\sqrt[3]{-125}$ en el conjunto de los números reales?",
          options: ["No existe en los números reales", "-5", "5", "-25"],
          correct: 1,
          explanation: "Como el índice es impar (3), la raíz de un número negativo sí existe en los reales: $(-5) \\times (-5) \\times (-5) = -125$."
        },
        {
          id: "q2_2",
          type: "choice",
          question: "¿Cuál de las siguientes raíces NO tiene solución en el conjunto de los números reales $\\mathbb{R}$?",
          options: ["$\\sqrt[3]{-27}$", "$\\sqrt[5]{-32}$", "$\\sqrt{-16}$", "$\\sqrt[3]{64}$"],
          correct: 2,
          explanation: "Las raíces de índice PAR (como la raíz cuadrada $n=2$) de números negativos no tienen solución en los números reales porque ningún número real al cuadrado da negativo."
        },
        {
          id: "q2_3",
          type: "input",
          question: "Calcula el valor exacto de: $\\sqrt[5]{32}$",
          placeholder: "Escribe tu respuesta numérica",
          acceptedAnswers: ["2"],
          explanation: "$2^5 = 2 \\times 2 \\times 2 \\times 2 \\times 2 = 32$, por lo tanto $\\sqrt[5]{32} = 2$."
        },
        {
          id: "q2_4",
          type: "choice",
          question: "¿Cuál de los siguientes radicales representa un número IRRACIONAL (raíz no exacta)?",
          options: ["$\\sqrt{64}$", "$\\sqrt{121}$", "$\\sqrt{50}$", "$\\sqrt{144}$"],
          correct: 2,
          explanation: "$\\sqrt{64}=8$, $\\sqrt{121}=11$, $\\sqrt{144}=12$ son exactas. En cambio, $50$ no es cuadrado perfecto, por lo que $\\sqrt{50} = 5\\sqrt{2} \\approx 7.071...$ es irracional."
        },
        {
          id: "q2_5",
          type: "input",
          question: "Calcula el valor de la operación: $\\sqrt[4]{16} + \\sqrt{49}$",
          placeholder: "Escribe tu respuesta",
          acceptedAnswers: ["9"],
          explanation: "$\\sqrt[4]{16} = 2$ (ya que $2^4 = 16$) y $\\sqrt{49} = 7$. Sumando: $2 + 7 = 9$."
        },
        {
          id: "q2_6",
          type: "choice",
          question: "Si el área de un cubo mágico es tal que su volumen es $216\\text{ cm}^3$, ¿cuánto mide la longitud de cada una de sus aristas?",
          options: ["$6\\text{ cm}$", "$14\\text{ cm}$", "$36\\text{ cm}$", "$72\\text{ cm}$"],
          correct: 0,
          explanation: "El volumen de un cubo es $V = L^3$. Para hallar la arista $L = \\sqrt[3]{216} = 6\\text{ cm}$, ya que $6 \\times 6 \\times 6 = 216$."
        }
      ]
    },

    {
      id: 3,
      title: "El Templo de las Leyes",
      subtitle: "Propiedades Fundamentales",
      icon: "🏛️",
      color: "#8b5cf6",
      darkColor: "#4c1d95",
      bgGradient: "from-purple-950 via-indigo-900 to-slate-900",
      boss: {
        name: "Esfinge de los Teoremas",
        title: "Custodia de las Tablas Sagradas",
        hp: 140,
        avatar: "🦁",
        dialogue: "¡Las leyes del álgebra son inmutables! Quien confunda el producto con la suma caerá en el abismo."
      },
      lesson: {
        intro: "En este templo milenario se encuentran esculpidas las 5 Leyes Sagradas de los Radicales. Dominarlas te otorgará el poder de transformar cualquier expresión compleja en algo simple.",
        sections: [
          {
            title: "Ley 1: Raíz de un Producto (Multiplicación)",
            content: `La raíz de una multiplicación es igual a la multiplicación de las raíces de cada factor, **siempre que tengan el mismo índice**:
$$\\sqrt[n]{a \\cdot b} = \\sqrt[n]{a} \\cdot \\sqrt[n]{b}$$
* **Ejemplo numérico:** $\\sqrt{4 \\times 9} = \\sqrt{4} \\times \\sqrt{9} = 2 \\times 3 = 6$.
* ¡También funciona en sentido inverso! Si tienes $\\sqrt{2} \\times \\sqrt{8}$, puedes unirlos: $\\sqrt{2 \\times 8} = \\sqrt{16} = 4$.`,
            formula: "\\sqrt[n]{a \\cdot b} = \\sqrt[n]{a} \\cdot \\sqrt[n]{b}"
          },
          {
            title: "Ley 2: Raíz de un Cociente (División / Fracción)",
            content: `La raíz de una división o fracción es igual a la división de la raíz del numerador entre la del denominador:
$$\\sqrt[n]{\\frac{a}{b}} = \\frac{\\sqrt[n]{a}}{\\sqrt[n]{b}} \\quad (b \\neq 0)$$
* **Ejemplo numérico:** $\\sqrt{\\frac{36}{49}} = \\frac{\\sqrt{36}}{\\sqrt{49}} = \\frac{6}{7}$.
* En sentido inverso: $\\frac{\\sqrt{50}}{\\sqrt{2}} = \\sqrt{\\frac{50}{2}} = \\sqrt{25} = 5$.`,
            formula: "\\sqrt[n]{\\frac{a}{b}} = \\frac{\\sqrt[n]{a}}{\\sqrt[n]{b}}"
          },
          {
            title: "Ley 3: Potencia de un Radical",
            content: `Para elevar un radical a una potencia, se eleva el radicando a dicha potencia:
$$(\\sqrt[n]{a})^m = \\sqrt[n]{a^m}$$
* **Ejemplo:** $(\\sqrt{9})^3 = 3^3 = 27$. O bien: $\\sqrt{9^3} = \\sqrt{729} = 27$. Ambos caminos llevan al mismo resultado.`,
            formula: "(\\sqrt[n]{a})^m = \\sqrt[n]{a^m}"
          },
          {
            title: "Ley 4: Raíz de una Raíz (Índices en Cascada)",
            content: `Cuando un radical está dentro de otro radical, **los índices se multiplican** y el radicando se mantiene igual:
$$\\sqrt[m]{\\sqrt[n]{a}} = \\sqrt[m \\cdot n]{a}$$
* **Ejemplo:** $\\sqrt{\\sqrt[3]{64}} = \\sqrt[2 \\times 3]{64} = \\sqrt[6]{64} = 2$ (porque $2^6 = 64$).
* ¡No sumes los índices! $2 \\times 3 = 6$, no $2+3=5$.`,
            formula: "\\sqrt[m]{\\sqrt[n]{a}} = \\sqrt[m \\cdot n]{a}"
          },
          {
            title: "Ley 5: Raíz de una Potencia con Mismo Índice",
            content: `Cuando el índice de la raíz y el exponente del radicando son idénticos, se cancelan mutuamente:
$$\\sqrt[n]{a^n} = a \\quad (\\text{para } a \\ge 0)$$
* **Ejemplo:** $\\sqrt[3]{5^3} = 5$, $\\sqrt[7]{x^7} = x$, $(\\sqrt{13})^2 = 13$.`,
            formula: "\\sqrt[n]{a^n} = a"
          },
          {
            title: "Ejemplo Resuelto Paso a Paso",
            example: {
              problem: "Simplifica aplicando propiedades: \\sqrt{3} \\cdot \\sqrt{12} + \\sqrt{\\sqrt{16}}",
              steps: [
                "Paso 1: Aplica la Ley 1 al primer término: \\sqrt{3} \\cdot \\sqrt{12} = \\sqrt{3 \\times 12} = \\sqrt{36}.",
                "Paso 2: Calcula esa raíz exacta: \\sqrt{36} = 6.",
                "Paso 3: Aplica la Ley 4 (raíz de raíz) al segundo término: \\sqrt{\\sqrt{16}} = \\sqrt[2 \\times 2]{16} = \\sqrt[4]{16}.",
                "Paso 4: Calcula esa raíz: \\sqrt[4]{16} = 2 (porque 2^4 = 16).",
                "Paso 5: Suma los resultados: 6 + 2 = 8.",
                "Resultado final: 8."
              ]
            }
          }
        ]
      },
      questions: [
        {
          id: "q3_1",
          type: "choice",
          question: "¿Cuál es el resultado simplificado de $\\sqrt{8} \\cdot \\sqrt{2}$ aplicando la propiedad del producto?",
          options: ["$\\sqrt{10}$", "$4$", "$16$", "$2\\sqrt{2}$"],
          correct: 1,
          explanation: "Por la propiedad del producto: $\\sqrt{8} \\cdot \\sqrt{2} = \\sqrt{8 \\times 2} = \\sqrt{16} = 4$."
        },
        {
          id: "q3_2",
          type: "choice",
          question: "¿Qué propiedad describe correctamente la expresión $\\sqrt[3]{\\sqrt[4]{x}}$?",
          options: [
            "$\\sqrt[7]{x}$ (se suman los índices)",
            "$\\sqrt[12]{x}$ (se multiplican los índices)",
            "$\\sqrt[1]{x}$ (se restan los índices)",
            "$\\sqrt[4/3]{x}$"
          ],
          correct: 1,
          explanation: "En la raíz de una raíz, los índices se multiplican: $3 \\times 4 = 12$, por lo que la expresión es $\\sqrt[12]{x}$."
        },
        {
          id: "q3_3",
          type: "input",
          question: "Calcula el valor de la expresión usando la propiedad del cociente: $\\frac{\\sqrt{72}}{\\sqrt{2}}$",
          placeholder: "Escribe tu respuesta",
          acceptedAnswers: ["6"],
          explanation: "$\\frac{\\sqrt{72}}{\\sqrt{2}} = \\sqrt{\\frac{72}{2}} = \\sqrt{36} = 6$."
        },
        {
          id: "q3_4",
          type: "choice",
          question: "¿Cuál de las siguientes igualdades es VERDADERA para números positivos?",
          options: [
            "$\\sqrt{x^2 + y^2} = x + y$",
            "$\\sqrt{x \\cdot y} = \\sqrt{x} \\cdot \\sqrt{y}$",
            "$\\sqrt{x - y} = \\sqrt{x} - \\sqrt{y}$",
            "$\\sqrt[3]{x} + \\sqrt[3]{y} = \\sqrt[3]{x+y}$"
          ],
          correct: 1,
          explanation: "La radicación se distribuye únicamente sobre la multiplicación y la división, NUNCA sobre la suma ni la resta."
        },
        {
          id: "q3_5",
          type: "input",
          question: "Calcula el resultado numérico de: $(\\sqrt[3]{7})^3 + \\sqrt[4]{5^4}$",
          placeholder: "Escribe el resultado",
          acceptedAnswers: ["12"],
          explanation: "Por la propiedad de cancelación: $(\\sqrt[3]{7})^3 = 7$ y $\\sqrt[4]{5^4} = 5$. Sumando: $7 + 5 = 12$."
        },
        {
          id: "q3_6",
          type: "choice",
          question: "¿Cómo se simplifica la expresión $\\sqrt{\\frac{100}{49}}$?",
          options: ["$\\frac{50}{7}$", "$\\frac{10}{7}$", "$\\frac{10}{49}$", "$\\frac{100}{7}$"],
          correct: 1,
          explanation: "Aplicando la propiedad del cociente: $\\frac{\\sqrt{100}}{\\sqrt{49}} = \\frac{10}{7}$."
        }
      ]
    },

    {
      id: 4,
      title: "La Forja de la Simplificación",
      subtitle: "Extracción de Factores y Descomposición",
      icon: "🔨",
      color: "#f59e0b",
      darkColor: "#78350f",
      bgGradient: "from-amber-950 via-orange-900 to-slate-900",
      boss: {
        name: "Herrero Gólem de Fuego",
        title: "Maestro de la Fundición Radical",
        hp: 160,
        avatar: "🔥",
        dialogue: "¡En mi forja no tolero impurezas! Si un factor puede salir de la raíz, ¡extrácelo o arderás!"
      },
      lesson: {
        intro: "Simplificar un radical es el arte de dejar la raíz en su forma más limpia y elegante posible: sacando todo lo que tenga raíz exacta y dejando adentro solo lo irreductible.",
        sections: [
          {
            title: "¿Cuándo un Radical está Totalmente Simplificado?",
            content: `Un radical está en su forma más simple si:
1. No quedan factores dentro del radicando con exponentes mayores o iguales al índice.
2. No hay fracciones dentro del radical.
3. No hay radicales en el denominador (racionalización).`
          },
          {
            title: "Método 1: Buscar Cuadrados Perfectos Ocultos",
            content: `Los primeros cuadrados perfectos son: **$4, 9, 16, 25, 36, 49, 64, 81, 100$**.
Busca el mayor de estos números que divida exactamente a tu radicando.

**Ejemplo Sagrado: Simplificar $\\sqrt{72}$**
* Paso 1: Busca divisores que sean cuadrados perfectos de 72:
  $72 = 36 \\times 2$ (¡36 es un cuadrado perfecto!).
* Paso 2: Separa usando la propiedad del producto:
  $$\\sqrt{72} = \\sqrt{36 \\times 2} = \\sqrt{36} \\times \\sqrt{2}$$
* Paso 3: Resuelve la raíz exacta: $\\sqrt{36} = 6$.
* Resultado final: **$6\\sqrt{2}$**.`
          },
          {
            title: "Método 2: Descomposición en Factores Primos",
            content: `Ideal para números grandes o expresiones algebraicas con letras:
1. Descompón el número en primos ($2, 3, 5, 7, 11...$).
2. Agrupa los factores en potencias iguales al índice.
3. Los que tengan potencia igual al índice **salen afuera** perdiendo su exponente; los que no, se quedan adentro.

**Ejemplo: Simplificar $\\sqrt{180}$**
* Descomposición: $180 = 2^2 \\times 3^2 \\times 5$.
* Reescribimos: $\\sqrt{2^2 \\times 3^2 \\times 5} = \\sqrt{2^2} \\times \\sqrt{3^2} \\times \\sqrt{5}$.
* Salen el 2 y el 3: $2 \\times 3 \\times \\sqrt{5} = 6\\sqrt{5}$.`
          },
          {
            title: "Extracción con Variables y Letras (La Regla de la División)",
            content: `Para simplificar variables como $\\sqrt{x^7}$ o $\\sqrt[3]{y^8}$:
* **Divide el exponente entre el índice**:
  * El **Cociente** es el exponente con el que sale la variable AFUERA.
  * El **Residuo** es el exponente con el que se queda la variable ADENTRO.
* **Ejemplo: $\\sqrt{x^7}$** (índice 2):
  $7 \\div 2 = 3$ y sobra $1$.
  Por lo tanto: sale $x^3$ y queda $x^1$ adentro $\\implies x^3\\sqrt{x}$.`
          },
          {
            title: "Errores Comunes",
            commonErrors: [
              {
                error: "Dejar la simplificación a medias: decir que $\\sqrt{72} = 2\\sqrt{18}$.",
                fix: "Aunque $72 = 4 \\times 18$, el 18 todavía contiene el cuadrado $9$. Siempre debes extraer el factor máximo: $6\\sqrt{2}$."
              },
              {
                error: "Sacar el número sin calcular su raíz (ej: decir que $\\sqrt{36 \\times 2} = 36\\sqrt{2}$).",
                fix: "Al salir de la raíz, se le DEBE aplicar la raíz: $\\sqrt{36} = 6$, por lo que sale como $6$, no como $36$."
              }
            ]
          }
        ]
      },
      questions: [
        {
          id: "q4_1",
          type: "choice",
          question: "¿Cuál es la forma completamente simplificada de $\\sqrt{50}$?",
          options: ["$2\\sqrt{5}$", "$5\\sqrt{2}$", "$25\\sqrt{2}$", "$10\\sqrt{5}$"],
          correct: 1,
          explanation: "$50 = 25 \\times 2$. Por tanto: $\\sqrt{50} = \\sqrt{25 \\times 2} = 5\\sqrt{2}$."
        },
        {
          id: "q4_2",
          type: "choice",
          question: "¿Cómo se simplifica el radical con variables $\\sqrt{x^9}$?",
          options: ["$x^4\\sqrt{x}$", "$x^3\\sqrt{x}$", "$x\\sqrt{x^8}$", "$x^8\\sqrt{x}$"],
          correct: 0,
          explanation: "Dividimos el exponente 9 entre el índice 2: $9 \\div 2 = 4$ con residuo 1. Sale $x^4$ y queda $x^1$ dentro: $x^4\\sqrt{x}$."
        },
        {
          id: "q4_3",
          type: "input",
          question: "Simplifica $\\sqrt{48}$. La respuesta tiene la forma $a\\sqrt{3}$. ¿Cuál es el valor del coeficiente entero $a$?",
          placeholder: "Escribe el número a",
          acceptedAnswers: ["4"],
          explanation: "$48 = 16 \\times 3$. $\\sqrt{48} = \\sqrt{16} \\times \\sqrt{3} = 4\\sqrt{3}$. El coeficiente $a$ es 4."
        },
        {
          id: "q4_4",
          type: "choice",
          question: "Simplifica la raíz cúbica: $\\sqrt[3]{54}$",
          options: ["$3\\sqrt[3]{2}$", "$2\\sqrt[3]{3}$", "$9\\sqrt[3]{6}$", "$6\\sqrt[3]{9}$"],
          correct: 0,
          explanation: "Buscamos un cubo perfecto: $54 = 27 \\times 2$. Como $\\sqrt[3]{27} = 3$, el resultado es $3\\sqrt[3]{2}$."
        },
        {
          id: "q4_5",
          type: "input",
          question: "Al simplificar $\\sqrt{200}$ se obtiene $k\\sqrt{2}$. ¿Cuál es el valor del número $k$?",
          placeholder: "Escribe el valor de k",
          acceptedAnswers: ["10"],
          explanation: "$200 = 100 \\times 2$. Por ende, $\\sqrt{200} = \\sqrt{100} \\times \\sqrt{2} = 10\\sqrt{2}$. El valor de $k$ es 10."
        },
        {
          id: "q4_6",
          type: "choice",
          question: "¿Cuál es la simplificación de $2\\sqrt{75}$?",
          options: ["$10\\sqrt{3}$", "$5\\sqrt{3}$", "$25\\sqrt{3}$", "$6\\sqrt{5}$"],
          correct: 0,
          explanation: "Primero simplificamos $\\sqrt{75} = \\sqrt{25 \\times 3} = 5\\sqrt{3}$. Luego multiplicamos por el coeficiente 2: $2 \\times 5\\sqrt{3} = 10\\sqrt{3}$."
        }
      ]
    },

    {
      id: 5,
      title: "El Valle de las Operaciones",
      subtitle: "Suma, Resta, Multiplicación y División",
      icon: "⚔️",
      color: "#ef4444",
      darkColor: "#7f1d1d",
      bgGradient: "from-rose-950 via-red-900 to-slate-900",
      boss: {
        name: "Quimera de las Expresiones",
        title: "Azote de los Términos Desemejantes",
        hp: 180,
        avatar: "👹",
        dialogue: "¡Solo los términos semejantes pueden unirse para desafiar mi furia! ¡Sepárate y perece!"
      },
      lesson: {
        intro: "En este valle los radicales entran en batalla: se suman, se restan, se multiplican y se dividen. Pero cuidado: hay reglas estrictas para combinar sus poderes.",
        sections: [
          {
            title: "1. Radicales Semejantes: La Regla de Oro",
            content: `Dos o más radicales son **SEMEJANTES** si tienen:
1. El **MISMO índice**, y
2. El **MISMO radicando**.

* $3\\sqrt{7}$ y $5\\sqrt{7}$ **SÍ son semejantes** (ambos tienen índice 2 y radicando 7).
* $4\\sqrt{3}$ y $4\\sqrt{5}$ **NO son semejantes** (radicando distinto).
* $2\\sqrt{5}$ y $2\\sqrt[3]{5}$ **NO son semejantes** (índice distinto).`
          },
          {
            title: "2. Suma y Resta de Radicales",
            content: `**¡REGLA ABSOLUTA!** Solo puedes sumar o restar radicales **si son semejantes**.
Se suman o restan los coeficientes exteriores y se conserva exactamente el mismo radical:
$$a\\sqrt[n]{x} + b\\sqrt[n]{x} = (a + b)\\sqrt[n]{x}$$

* **Ejemplo directo:** $7\\sqrt{2} + 3\\sqrt{2} - 4\\sqrt{2} = (7 + 3 - 4)\\sqrt{2} = 6\\sqrt{2}$.
* **¿Qué pasa si parecen no ser semejantes?** ¡Primero simplifica!
  $$\\sqrt{12} + \\sqrt{27}$$
  * $\\sqrt{12} = \\sqrt{4 \\times 3} = 2\\sqrt{3}$
  * $\\sqrt{27} = \\sqrt{9 \\times 3} = 3\\sqrt{3}$
  * Ahora sí son semejantes: $2\\sqrt{3} + 3\\sqrt{3} = 5\\sqrt{3}$.`
          },
          {
            title: "3. Multiplicación de Radicales",
            content: `* **Con el mismo índice:** Multiplica coeficientes con coeficientes y radicandos con radicandos:
  $$(a\\sqrt[n]{x}) \\cdot (b\\sqrt[n]{y}) = (a \\cdot b)\\sqrt[n]{x \\cdot y}$$
  * **Ejemplo:** $2\\sqrt{3} \\times 5\\sqrt{6} = 10\\sqrt{18}$.
    Ahora simplificamos $18$: $\\sqrt{18} = \\sqrt{9 \\times 2} = 3\\sqrt{2}$.
    Multiplicando: $10 \\times 3\\sqrt{2} = 30\\sqrt{2}$.
* **Propiedad Distributiva:**
  $$\\sqrt{2}(3 + \\sqrt{8}) = 3\\sqrt{2} + \\sqrt{16} = 3\\sqrt{2} + 4$$`
          },
          {
            title: "4. División de Radicales",
            content: `Se dividen los coeficientes entre sí y los radicandos entre sí:
$$\\frac{a\\sqrt[n]{x}}{b\\sqrt[n]{y}} = \\frac{a}{b}\\sqrt[n]{\\frac{x}{y}}$$
* **Ejemplo:** $\\frac{12\\sqrt{50}}{3\\sqrt{2}} = 4\\sqrt{\\frac{50}{2}} = 4\\sqrt{25} = 4 \\times 5 = 20$.`
          },
          {
            title: "Errores Comunes",
            commonErrors: [
              {
                error: "Sumar los radicandos: pensar que $\\sqrt{3} + \\sqrt{5} = \\sqrt{8}$.",
                fix: "¡NUNCA sumes lo de adentro! $\\sqrt{3} + \\sqrt{5}$ no se puede sumar; se deja indicado así mismo."
              },
              {
                error: "Al sumar $1\\sqrt{2} + 1\\sqrt{2}$, poner solo $\\sqrt{4}$.",
                fix: "$1\\sqrt{2} + 1\\sqrt{2} = 2\\sqrt{2}$. La raíz funciona como una manzana: 1 manzana + 1 manzana = 2 manzanas."
              }
            ]
          }
        ]
      },
      questions: [
        {
          id: "q5_1",
          type: "choice",
          question: "¿Cuál es el resultado de la operación: $5\\sqrt{3} + 4\\sqrt{3} - 2\\sqrt{3}$?",
          options: ["$7\\sqrt{9}$", "$7\\sqrt{3}$", "$9\\sqrt{3}$", "$7$"],
          correct: 1,
          explanation: "Como son radicales semejantes, operamos los coeficientes: $(5 + 4 - 2)\\sqrt{3} = 7\\sqrt{3}$."
        },
        {
          id: "q5_2",
          type: "choice",
          question: "Calcula la suma tras simplificar: $\\sqrt{12} + \\sqrt{75}$",
          options: ["$\\sqrt{87}$", "$7\\sqrt{3}$", "$10\\sqrt{3}$", "$9\\sqrt{3}$"],
          correct: 1,
          explanation: "$\\sqrt{12} = 2\\sqrt{3}$ y $\\sqrt{75} = 5\\sqrt{3}$. Sumando ambos términos semejantes: $2\\sqrt{3} + 5\\sqrt{3} = 7\\sqrt{3}$."
        },
        {
          id: "q5_3",
          type: "input",
          question: "Calcula el valor entero de la multiplicación: $(3\\sqrt{2}) \\cdot (4\\sqrt{2})$",
          placeholder: "Escribe el número resultante",
          acceptedAnswers: ["24"],
          explanation: "Multiplicamos coeficientes: $3 \\times 4 = 12$. Multiplicamos radicales: $\\sqrt{2} \\times \\sqrt{2} = \\sqrt{4} = 2$. Finalmente: $12 \\times 2 = 24$."
        },
        {
          id: "q5_4",
          type: "choice",
          question: "Al realizar la división $\\frac{15\\sqrt{48}}{3\\sqrt{3}}$, ¿cuál es el resultado final?",
          options: ["$20$", "$5\\sqrt{16}$", "$5\\sqrt{3}$", "$12$"],
          correct: 0,
          explanation: "Dividimos coeficientes: $15 \\div 3 = 5$. Dividimos radicandos: $\\sqrt{48/3} = \\sqrt{16} = 4$. Multiplicamos: $5 \\times 4 = 20$."
        },
        {
          id: "q5_5",
          type: "choice",
          question: "Aplica la propiedad distributiva a $\\sqrt{3}(2 + \\sqrt{3})$:",
          options: ["$2\\sqrt{3} + 3$", "$5\\sqrt{3}$", "$2\\sqrt{3} + 9$", "$6$"],
          correct: 0,
          explanation: "$\\sqrt{3} \\times 2 = 2\\sqrt{3}$, y $\\sqrt{3} \\times \\sqrt{3} = (\\sqrt{3})^2 = 3$. El resultado es $2\\sqrt{3} + 3$."
        },
        {
          id: "q5_6",
          type: "input",
          question: "Simplifica $\\sqrt{20} + \\sqrt{45}$. La respuesta es de la forma $c\\sqrt{5}$. ¿Cuánto vale el coeficiente $c$?",
          placeholder: "Escribe el coeficiente c",
          acceptedAnswers: ["5"],
          explanation: "$\\sqrt{20} = 2\\sqrt{5}$ y $\\sqrt{45} = 3\\sqrt{5}$. Sumando: $2\\sqrt{5} + 3\\sqrt{5} = 5\\sqrt{5}$. El coeficiente $c$ es 5."
        }
      ]
    },

    {
      id: 6,
      title: "La Cascada de la Racionalización",
      subtitle: "Eliminación de Radicales del Denominador",
      icon: "🌊",
      color: "#0ea5e9",
      darkColor: "#0369a1",
      bgGradient: "from-blue-950 via-sky-900 to-slate-900",
      boss: {
        name: "Leviatán del Denominador",
        title: "Monstruo de las Fracciones Turbias",
        hp: 200,
        avatar: "🦑",
        dialogue: "¡No toleraré raíces bajo mis aguas! ¡Limpia el denominador o serás arrastrado a la corriente!"
      },
      lesson: {
        intro: "En matemáticas tradicionales, dejar una raíz en el denominador se considera una forma incompleta. Racionalizar es el proceso de transformar la fracción para eliminar todo radical del denominador sin cambiar su valor numérico.",
        sections: [
          {
            title: "¿Qué significa Racionalizar?",
            content: `Racionalizar una fracción consiste en encontrar una **fracción equivalente** donde el denominador sea un número entero (racional), libre de cualquier raíz.
Para lograrlo, multiplicamos el numerador y el denominador por un **'1 conveniente'** (una expresión que valga 1 para no alterar el valor).`
          },
          {
            title: "Caso 1: Denominador con una Raíz Cuadrada Simple (Monomio)",
            content: `Si tienes la forma $\\frac{a}{\\sqrt{b}}$, multiplicas arriba y abajo por $\\sqrt{b}$:
$$\\frac{a}{\\sqrt{b}} = \\frac{a}{\\sqrt{b}} \\cdot \\frac{\\sqrt{b}}{\\sqrt{b}} = \\frac{a\\sqrt{b}}{(\\sqrt{b})^2} = \\frac{a\\sqrt{b}}{b}$$

**Ejemplo 1:** Racionalizar $\\frac{6}{\\sqrt{3}}$
1. Multiplica por $\\frac{\\sqrt{3}}{\\sqrt{3}}$:
   $$\\frac{6}{\\sqrt{3}} \\cdot \\frac{\\sqrt{3}}{\\sqrt{3}} = \\frac{6\\sqrt{3}}{3}$$
2. Simplifica la fracción si es posible ($6 \\div 3 = 2$):
   $$= 2\\sqrt{3}$$

**Ejemplo 2:** $\\frac{10}{\\sqrt{5}} = \\frac{10\\sqrt{5}}{5} = 2\\sqrt{5}$.`
          },
          {
            title: "Caso 2: Denominador Binomio (Binomios Conjugados)",
            content: `Si el denominador es una suma o resta que contiene raíces, como $(\\sqrt{a} + b)$ o $(\\sqrt{a} - \\sqrt{b})$, usamos el **CONJUGADO**.
* El conjugado de $(x + y)$ es $(x - y)$.
* El conjugado de $(x - y)$ es $(x + y)$.

Al multiplicarlos, se aplica el producto notable de **Diferencia de Cuadrados**:
$$(x + y)(x - y) = x^2 - y^2$$
¡Al elevar cada término al cuadrado, las raíces se destruyen por completo!

**Ejemplo Mítico: Racionalizar $\\frac{4}{\\sqrt{5} - 1}$**
1. Identifica el conjugado del denominador $(\\sqrt{5} - 1)$: es $(\\sqrt{5} + 1)$.
2. Multiplica arriba y abajo:
   $$\\frac{4}{\\sqrt{5} - 1} \\cdot \\frac{\\sqrt{5} + 1}{\\sqrt{5} + 1}$$
3. Resuelve el denominador usando diferencia de cuadrados:
   $$(\\sqrt{5})^2 - (1)^2 = 5 - 1 = 4$$
4. Escribe la fracción resultante:
   $$\\frac{4(\\sqrt{5} + 1)}{4} = \\sqrt{5} + 1$$`
          },
          {
            title: "Errores Comunes",
            commonErrors: [
              {
                error: "Multiplicar solo el denominador por la raíz y olvidar el numerador.",
                fix: "Si no multiplicas arriba y abajo por lo mismo, cambias el valor de la fracción. $\\frac{\\sqrt{b}}{\\sqrt{b}} = 1$."
              },
              {
                error: "En un binomio, multiplicar por el mismo signo en vez del signo contrario.",
                fix: "Si tienes $(\\sqrt{5} - 1)$ y multiplicas por $(\\sqrt{5} - 1)$, obtienes $(\\sqrt{5}-1)^2 = 5 - 2\\sqrt{5} + 1 = 6 - 2\\sqrt{5}$. ¡La raíz NO se fue! Debe ser el conjugado con signo opuesto."
              }
            ]
          }
        ]
      },
      questions: [
        {
          id: "q6_1",
          type: "choice",
          question: "¿Por qué factor debes multiplicar el numerador y denominador para racionalizar $\\frac{5}{\\sqrt{7}}$?",
          options: ["$\\frac{7}{7}$", "$\\frac{\\sqrt{7}}{\\sqrt{7}}$", "$\\frac{5}{5}$", "$\\frac{\\sqrt{5}}{\\sqrt{5}}$"],
          correct: 1,
          explanation: "Para eliminar $\\sqrt{7}$ del denominador, multiplicamos por el '1 conveniente' formado por $\\frac{\\sqrt{7}}{\\sqrt{7}}$."
        },
        {
          id: "q6_2",
          type: "choice",
          question: "Al racionalizar y simplificar la fracción $\\frac{12}{\\sqrt{6}}$, se obtiene:",
          options: ["$2\\sqrt{6}$", "$6\\sqrt{2}$", "$12\\sqrt{6}$", "$2$"],
          correct: 0,
          explanation: "$\\frac{12}{\\sqrt{6}} \\cdot \\frac{\\sqrt{6}}{\\sqrt{6}} = \\frac{12\\sqrt{6}}{6} = 2\\sqrt{6}$."
        },
        {
          id: "q6_3",
          type: "choice",
          question: "¿Cuál es el binomio conjugado de $(\\sqrt{7} - 3)$?",
          options: ["$(\\sqrt{7} - 3)$", "$(-\\sqrt{7} - 3)$", "$(\\sqrt{7} + 3)$", "$(7 + 3)$"],
          correct: 2,
          explanation: "El conjugado de un binomio se obtiene cambiando el signo que separa los dos términos: de resta a suma, es decir, $(\\sqrt{7} + 3)$."
        },
        {
          id: "q6_4",
          type: "input",
          question: "Racionaliza $\\frac{14}{\\sqrt{2}}$. El resultado es $k\\sqrt{2}$. ¿Cuál es el valor del número entero $k$?",
          placeholder: "Escribe el valor de k",
          acceptedAnswers: ["7"],
          explanation: "$\\frac{14}{\\sqrt{2}} \\cdot \\frac{\\sqrt{2}}{\\sqrt{2}} = \\frac{14\\sqrt{2}}{2} = 7\\sqrt{2}$. Por tanto, $k = 7$."
        },
        {
          id: "q6_5",
          type: "choice",
          question: "Al racionalizar $\\frac{2}{\\sqrt{3} + 1}$, ¿cuál es el resultado simplificado?",
          options: ["$\\sqrt{3} - 1$", "$2(\\sqrt{3} - 1)$", "$\\frac{\\sqrt{3} + 1}{2}$", "$\\sqrt{3} + 1$"],
          correct: 0,
          explanation: "Multiplicamos por el conjugado: $\\frac{2(\\sqrt{3}-1)}{(\\sqrt{3})^2 - 1^2} = \\frac{2(\\sqrt{3}-1)}{3 - 1} = \\frac{2(\\sqrt{3}-1)}{2} = \\sqrt{3} - 1$."
        },
        {
          id: "q6_6",
          type: "choice",
          question: "¿Cuál es la razón principal por la que los matemáticos racionalizan fracciones?",
          options: [
            "Porque las raíces en el denominador dan números negativos.",
            "Para estandarizar resultados, facilitar divisiones manuales y permitir sumar fracciones con denominadores comunes.",
            "Porque la raíz en el denominador no se puede graficar en el plano cartesiano.",
            "Para cambiar el valor numérico a un número entero."
          ],
          correct: 1,
          explanation: "Racionalizar permite estandarizar las expresiones algebraicas, facilita encontrar el común denominador y simplifica cálculos."
        }
      ]
    },

    {
      id: 7,
      title: "La Torre del Infinito Cuántico",
      subtitle: "Potencias y Exponentes Fraccionarios",
      icon: "⚡",
      color: "#ec4899",
      darkColor: "#831843",
      bgGradient: "from-fuchsia-950 via-pink-900 to-slate-900",
      boss: {
        name: "Archimago del Vacío Exponencial",
        title: "Señor de la Dualidad Raíz-Potencia",
        hp: 220,
        avatar: "🧙‍♂️",
        dialogue: "¡Radicales y exponentes son dos caras de la misma moneda cósmica! ¡Comprende la fracción o caerás en el vacío!"
      },
      lesson: {
        intro: "En la cúspide de la torre descubres el secreto final del álgebra: ¡Toda raíz es en realidad una potencia con un exponente fraccionario!",
        sections: [
          {
            title: "1. La Gran Regla de Equivalencia",
            content: `Un radical se puede escribir como una potencia donde el exponente es una fracción:
$$\\sqrt[n]{a^m} = a^{\\frac{m}{n}}$$

* **Mnemotecnia Sagrada (El Jinete y el Caballo):**
  * La potencia $m$ está **adentro** del refugio $\\implies$ en la fracción sube al **numerador** (arriba).
  * El índice $n$ está **afuera** a la intemperie $\\implies$ en la fracción baja al **denominador** (abajo).
  * En palabras simples: **Exponente arriba, Índice abajo**.

* Caso especial cuando no hay potencia interior ($m = 1$):
  $$\\sqrt[n]{a} = a^{\\frac{1}{n}}$$
  * $\\sqrt{x} = x^{\\frac{1}{2}}$
  * $\\sqrt[3]{x} = x^{\\frac{1}{3}}$
  * $\\sqrt[4]{x} = x^{\\frac{1}{4}}$`
          },
          {
            title: "2. Conversión de Radical a Potencia Fraccionaria",
            content: `* $\\sqrt[3]{x^5} = x^{\\frac{5}{3}}$
* $\\sqrt[4]{a^7} = a^{\\frac{7}{4}}$
* $\\sqrt{y^3} = y^{\\frac{3}{2}}$ (recuerda que el índice invisible es 2).`
          },
          {
            title: "3. Conversión de Potencia Fraccionaria a Radical",
            content: `Para evaluar números con potencias fraccionarias, conviene convertirlos a raíz:
$$a^{\\frac{m}{n}} = (\\sqrt[n]{a})^m$$

* **Ejemplo 1:** Calcular $16^{\\frac{3}{4}}$
  1. El denominador 4 pasa a ser el índice: $\\sqrt[4]{16}$.
  2. El numerador 3 es la potencia: $(\\sqrt[4]{16})^3$.
  3. Resolvemos la raíz primero (es más fácil): $\\sqrt[4]{16} = 2$.
  4. Elevamos a la potencia: $2^3 = 8$.
  5. ¡Así de fácil: $16^{3/4} = 8$!

* **Ejemplo 2:** Calcular $27^{\\frac{2}{3}}$
  $$(\\sqrt[3]{27})^2 = 3^2 = 9$$

* **Ejemplo 3 (Exponentes Negativos):** $16^{-\\frac{1}{2}} = \\frac{1}{16^{1/2}} = \\frac{1}{\\sqrt{16}} = \\frac{1}{4}$.`
          },
          {
            title: "4. Multiplicación con Diferentes Índices usando Exponentes",
            content: `¿Cómo multiplicar $\\sqrt{x} \\cdot \\sqrt[3]{x}$?
1. Pasa a potencias fraccionarias: $x^{1/2} \\cdot x^{1/3}$.
2. Aplica la ley de los exponentes (bases iguales se suman los exponentes):
   $$\\frac{1}{2} + \\frac{1}{3} = \\frac{3 + 2}{6} = \\frac{5}{6}$$
3. Regresa a radical:
   $$x^{\\frac{5}{6}} = \\sqrt[6]{x^5}$$`
          },
          {
            title: "Errores Comunes",
            commonErrors: [
              {
                error: "Invertir la fracción: escribir $\\sqrt[3]{x^2} = x^{3/2}$.",
                fix: "Recuerda: el índice de la raíz SIEMPRE va en el denominador (abajo). Lo correcto es $x^{2/3}$."
              },
              {
                error: "Pensar que un exponente fraccionario negativo hace negativo al número.",
                fix: "Un exponente negativo invierte la base a una fracción, pero no la hace negativa: $4^{-1/2} = \\frac{1}{\\sqrt{4}} = \\frac{1}{2}$."
              }
            ]
          }
        ]
      },
      questions: [
        {
          id: "q7_1",
          type: "choice",
          question: "¿Cómo se escribe la expresión radical $\\sqrt[5]{x^3}$ como una potencia con exponente fraccionario?",
          options: ["$x^{5/3}$", "$x^{3/5}$", "$x^{15}$", "$x^{-3/5}$"],
          correct: 1,
          explanation: "Por la regla fundamental: la potencia interior (3) va en el numerador y el índice de la raíz (5) va en el denominador: $x^{3/5}$."
        },
        {
          id: "q7_2",
          type: "input",
          question: "Calcula el valor numérico exacto de: $8^{\\frac{2}{3}}$",
          placeholder: "Escribe el número entero",
          acceptedAnswers: ["4"],
          explanation: "$8^{2/3} = (\\sqrt[3]{8})^2 = 2^2 = 4$."
        },
        {
          id: "q7_3",
          type: "input",
          question: "Calcula el valor numérico de: $81^{\\frac{3}{4}}$",
          placeholder: "Escribe tu respuesta",
          acceptedAnswers: ["27"],
          explanation: "$81^{3/4} = (\\sqrt[4]{81})^3 = 3^3 = 27$."
        },
        {
          id: "q7_4",
          type: "choice",
          question: "¿Cuál es la expresión equivalente en radical de $y^{\\frac{7}{4}}$?",
          options: ["$\\sqrt[7]{y^4}$", "$\\sqrt[4]{y^7}$", "$\\sqrt[11]{y}$", "$\\frac{7}{4}\\sqrt{y}$"],
          correct: 1,
          explanation: "El denominador 4 es el índice y el numerador 7 es la potencia interior: $\\sqrt[4]{y^7}$."
        },
        {
          id: "q7_5",
          type: "choice",
          question: "¿Cuál es el valor de $25^{-\\frac{1}{2}}$?",
          options: ["$-5$", "$\\frac{1}{5}$", "$-\\frac{1}{5}$", "$-25$"],
          correct: 1,
          explanation: "$25^{-1/2} = \\frac{1}{25^{1/2}} = \\frac{1}{\\sqrt{25}} = \\frac{1}{5}$."
        },
        {
          id: "q7_6",
          type: "choice",
          question: "Al multiplicar $\\sqrt{a} \\cdot \\sqrt[3]{a}$ usando exponentes fraccionarios, ¿cuál es el radical resultante?",
          options: ["$\\sqrt[6]{a^5}$", "$\\sqrt[5]{a^6}$", "$\\sqrt[6]{a}$", "$\\sqrt[5]{a}$"],
          correct: 0,
          explanation: "$a^{1/2} \\cdot a^{1/3} = a^{1/2 + 1/3} = a^{5/6} = \\sqrt[6]{a^5}$."
        }
      ]
    }
  ],

  // Gran Examen Final de la Ciudadela (20 preguntas integrales)
  finalExam: {
    title: "La Gran Ciudadela del Rey Radical",
    subtitle: "Examen Final de Maestría Algebraica (20 Desafíos)",
    description: "Pon a prueba todo lo aprendido a lo largo de los 7 reinos para coronarte como el Archimago Supremo de las Raíces.",
    boss: {
      name: "El Dragón Emperador de los Radicales",
      title: "Monarca Supremo del Cosmos Algebraico",
      hp: 500,
      avatar: "🐲",
      dialogue: "¡Has llegado a la cúspide de mi fortaleza! Para reclamar la Corona Radical, deberás vencer a mis 20 pruebas legendarias sin flaquear."
    },
    questions: [
      {
        id: "fe_1",
        realm: 1,
        question: "¿Cuál es la definición matemática más precisa de un radical?",
        options: [
          "Una suma abreviada de números enteros.",
          "La expresión que indica la operación inversa a la potenciación para hallar la base.",
          "Una división repetida entre el número 2.",
          "Cualquier número irracional con infinitos decimales."
        ],
        correct: 1,
        explanation: "La radicación es la operación inversa a la potenciación: si $b^n = a$, entonces $\\sqrt[n]{a} = b$."
      },
      {
        id: "fe_2",
        realm: 1,
        question: "En la expresión radical $-5\\sqrt[3]{64} = -20$, ¿cuál es el radicando?",
        options: ["$-5$", "$3$", "$64$", "$-20$"],
        correct: 2,
        explanation: "El radicando es la cantidad que se encuentra dentro del signo radical, que es 64."
      },
      {
        id: "fe_3",
        realm: 1,
        question: "Si el área de un terreno cuadrado mide $225\\text{ m}^2$, ¿cuánto mide cada uno de sus lados?",
        options: ["$15\\text{ m}$", "$25\\text{ m}$", "$112.5\\text{ m}$", "$50\\text{ m}$"],
        correct: 0,
        explanation: "El lado de un cuadrado es la raíz cuadrada del área: $\\sqrt{225} = 15\\text{ m}$ (porque $15 \\times 15 = 225$)."
      },
      {
        id: "fe_4",
        realm: 2,
        question: "¿Cuál es el valor en los números reales de $\\sqrt[3]{-216}$?",
        options: ["No tiene solución real", "$-6$", "$6$", "$-36$"],
        correct: 1,
        explanation: "Como el índice 3 es impar, $(-6)^3 = -216$, por lo que la raíz cúbica de $-216$ es $-6$."
      },
      {
        id: "fe_5",
        realm: 2,
        question: "¿Por qué $\\sqrt{-25}$ no tiene solución en el conjunto de los números reales $\\mathbb{R}$?",
        options: [
          "Porque el 25 no es un cuadrado perfecto.",
          "Porque el producto de dos números con el mismo signo nunca da un resultado negativo.",
          "Porque el signo radical no acepta números mayores a 20.",
          "Porque da cero."
        ],
        correct: 1,
        explanation: "Cualquier número real elevado al cuadrado da positivo: $(+5)^2 = 25$ y $(-5)^2 = 25$. Nunca da negativo en $\\mathbb{R}$."
      },
      {
        id: "fe_6",
        realm: 2,
        question: "¿Cuál de los siguientes números es una raíz EXACTA (racional)?",
        options: ["$\\sqrt{45}$", "$\\sqrt[3]{100}$", "$\\sqrt[4]{16}$", "$\\sqrt{12}$"],
        correct: 2,
        explanation: "$\\sqrt[4]{16} = 2$ es un número entero exacto (ya que $2^4 = 16$). Los demás producen decimales infinitos irracionales."
      },
      {
        id: "fe_7",
        realm: 3,
        question: "Aplica las propiedades para calcular el valor exacto de: $\\sqrt{50} \\cdot \\sqrt{2}$",
        options: ["$\\sqrt{52}$", "$10$", "$25$", "$100$"],
        correct: 1,
        explanation: "$\\sqrt{50} \\cdot \\sqrt{2} = \\sqrt{50 \\times 2} = \\sqrt{100} = 10$."
      },
      {
        id: "fe_8",
        realm: 3,
        question: "Simplifica la expresión de raíz de una raíz: $\\sqrt[3]{\\sqrt{x^6}}$",
        options: ["$x$", "$x^2$", "$x^6$", "$\\sqrt[5]{x^6}$"],
        correct: 0,
        explanation: "Multiplicamos índices: $3 \\times 2 = 6 \\implies \\sqrt[6]{x^6} = x$."
      },
      {
        id: "fe_9",
        realm: 3,
        question: "¿Cuál de las siguientes operaciones es matemáticamente FALSA?",
        options: [
          "$\\sqrt{\\frac{a}{b}} = \\frac{\\sqrt{a}}{\\sqrt{b}}$",
          "$\\sqrt{a \\cdot b} = \\sqrt{a} \\cdot \\sqrt{b}$",
          "$\\sqrt{a + b} = \\sqrt{a} + \\sqrt{b}$",
          "$(\\sqrt{a})^2 = a$"
        ],
        correct: 2,
        explanation: "La raíz NO se distribuye sobre la suma: $\\sqrt{a+b} \\neq \\sqrt{a} + \\sqrt{b}$."
      },
      {
        id: "fe_10",
        realm: 4,
        question: "Simplifica por completo el radical: $\\sqrt{72}$",
        options: ["$36\\sqrt{2}$", "$2\\sqrt{18}$", "$6\\sqrt{2}$", "$8\\sqrt{3}$"],
        correct: 2,
        explanation: "$72 = 36 \\times 2 \\implies \\sqrt{72} = \\sqrt{36} \\times \\sqrt{2} = 6\\sqrt{2}$."
      },
      {
        id: "fe_11",
        realm: 4,
        question: "Extrae todos los factores posibles de la raíz cuadrada: $\\sqrt{75 x^5}$",
        options: ["$5x^2\\sqrt{3x}$", "$25x^4\\sqrt{3x}$", "$15x^2\\sqrt{5x}$", "$5x\\sqrt{15x}$"],
        correct: 0,
        explanation: "$75 = 25 \\times 3 \\implies 5\\sqrt{3}$. Para $x^5$: $5 \\div 2 = 2$ residuo $1 \\implies x^2\\sqrt{x}$. Juntos: $5x^2\\sqrt{3x}$."
      },
      {
        id: "fe_12",
        realm: 4,
        question: "Simplifica la raíz cúbica: $\\sqrt[3]{128}$",
        options: ["$4\\sqrt[3]{2}$", "$2\\sqrt[3]{4}$", "$8\\sqrt[3]{2}$", "$16\\sqrt[3]{2}$"],
        correct: 0,
        explanation: "$128 = 64 \\times 2$. Como $64$ es el cubo perfecto de $4$ ($4^3 = 64$), tenemos $\\sqrt[3]{128} = 4\\sqrt[3]{2}$."
      },
      {
        id: "fe_13",
        realm: 5,
        question: "Resuelve la suma de radicales: $3\\sqrt{20} - 2\\sqrt{45} + \\sqrt{5}$",
        options: ["$\\sqrt{5}$", "$2\\sqrt{5}$", "$5\\sqrt{5}$", "$0$"],
        correct: 0,
        explanation: "$3\\sqrt{20} = 3(2\\sqrt{5}) = 6\\sqrt{5}$. $2\\sqrt{45} = 2(3\\sqrt{5}) = 6\\sqrt{5}$. Operando: $6\\sqrt{5} - 6\\sqrt{5} + \\sqrt{5} = \\sqrt{5}$."
      },
      {
        id: "fe_14",
        realm: 5,
        question: "Realiza la multiplicación: $(2\\sqrt{3}) \\cdot (3\\sqrt{6})$ y simplifica al máximo:",
        options: ["$6\\sqrt{18}$", "$18\\sqrt{2}$", "$36$", "$18$"],
        correct: 1,
        explanation: "Coeficientes: $2 \\times 3 = 6$. Radicales: $\\sqrt{3 \\times 6} = \\sqrt{18} = 3\\sqrt{2}$. Multiplicando: $6 \\times 3\\sqrt{2} = 18\\sqrt{2}$."
      },
      {
        id: "fe_15",
        realm: 5,
        question: "Divide y simplifica: $\\frac{10\\sqrt{32}}{2\\sqrt{2}}$",
        options: ["$20$", "$5\\sqrt{16}$", "$10$", "$40$"],
        correct: 0,
        explanation: "$10 \\div 2 = 5$. $\\sqrt{32/2} = \\sqrt{16} = 4$. Por lo tanto, $5 \\times 4 = 20$."
      },
      {
        id: "fe_16",
        realm: 6,
        question: "Racionaliza la fracción con monomio: $\\frac{8}{\\sqrt{2}}$",
        options: ["$4\\sqrt{2}$", "$8\\sqrt{2}$", "$2\\sqrt{8}$", "$4$"],
        correct: 0,
        explanation: "$\\frac{8}{\\sqrt{2}} \\cdot \\frac{\\sqrt{2}}{\\sqrt{2}} = \\frac{8\\sqrt{2}}{2} = 4\\sqrt{2}$."
      },
      {
        id: "fe_17",
        realm: 6,
        question: "Racionaliza la fracción con binomio conjugado: $\\frac{6}{\\sqrt{5} - \\sqrt{2}}$",
        options: [
          "$2(\\sqrt{5} + \\sqrt{2})$",
          "$\\frac{6(\\sqrt{5} + \\sqrt{2})}{3}$",
          "$2(\\sqrt{5} - \\sqrt{2})$",
          "$\\sqrt{5} + \\sqrt{2}$"
        ],
        correct: 0,
        explanation: "Denominador: $(\\sqrt{5})^2 - (\\sqrt{2})^2 = 5 - 2 = 3$. Numerador: $6(\\sqrt{5}+\\sqrt{2})$. Dividiendo $6/3$: $2(\\sqrt{5}+\\sqrt{2})$."
      },
      {
        id: "fe_18",
        realm: 7,
        question: "¿Cómo se expresa $\\sqrt[4]{x^9}$ en forma de potencia?",
        options: ["$x^{4/9}$", "$x^{9/4}$", "$x^{36}$", "$x^{5}$"],
        correct: 1,
        explanation: "El exponente interior (9) va arriba en el numerador y el índice (4) va abajo en el denominador: $x^{9/4}$."
      },
      {
        id: "fe_19",
        realm: 7,
        question: "Calcula el valor numérico de la potencia: $64^{\\frac{2}{3}}$",
        options: ["$16$", "$8$", "$32$", "$4$"],
        correct: 0,
        explanation: "$64^{2/3} = (\\sqrt[3]{64})^2 = 4^2 = 16$."
      },
      {
        id: "fe_20",
        realm: 7,
        question: "Calcula el valor de la expresión: $9^{\\frac{3}{2}} + 32^{\\frac{1}{5}}$",
        options: ["$29$", "$31$", "$27$", "$25$"],
        correct: 0,
        explanation: "$9^{3/2} = (\\sqrt{9})^3 = 3^3 = 27$. $32^{1/5} = \\sqrt[5]{32} = 2$. Sumando: $27 + 2 = 29$."
      }
    ]
  },

  // Códice de Fórmulas y Propiedades
  formulasCodex: [
    {
      category: "Definición y Elementos",
      items: [
        {
          name: "Definición Fundamental",
          formula: "\\sqrt[n]{a} = b \\iff b^n = a",
          desc: "La raíz enésima de 'a' es 'b' si y solo si 'b' elevado a la potencia 'n' resulta en 'a'."
        },
        {
          name: "Partes de un Radical",
          formula: "c\\sqrt[n]{a} = b",
          desc: "c: Coeficiente | n: Índice (n≥2) | √: Signo radical | a: Radicando | b: Raíz."
        },
        {
          name: "Raíz Cuadrada por Defecto",
          formula: "\\sqrt{a} = \\sqrt[2]{a}",
          desc: "Cuando no se escribe el índice en un radical, se sobreentiende universalmente que el índice es 2."
        }
      ]
    },
    {
      category: "Leyes y Propiedades de los Radicales",
      items: [
        {
          name: "Raíz de un Producto",
          formula: "\\sqrt[n]{a \\cdot b} = \\sqrt[n]{a} \\cdot \\sqrt[n]{b}",
          desc: "La raíz de una multiplicación es igual al producto de las raíces individuales (para el mismo índice)."
        },
        {
          name: "Raíz de un Cociente",
          formula: "\\sqrt[n]{\\frac{a}{b}} = \\frac{\\sqrt[n]{a}}{\\sqrt[n]{b}}",
          desc: "La raíz de una división es igual a la división de las raíces del numerador y denominador."
        },
        {
          name: "Potencia de un Radical",
          formula: "(\\sqrt[n]{a})^m = \\sqrt[n]{a^m}",
          desc: "Elevar una raíz a una potencia equivale a elevar el radicando a dicha potencia dentro del radical."
        },
        {
          name: "Raíz de una Raíz",
          formula: "\\sqrt[m]{\\sqrt[n]{a}} = \\sqrt[m \\cdot n]{a}",
          desc: "Los índices consecutivos se multiplican para formar un solo radical."
        },
        {
          name: "Cancelación de Índice y Potencia",
          formula: "\\sqrt[n]{a^n} = a \\quad (a \\ge 0)",
          desc: "Si el índice de la raíz y el exponente del radicando son idénticos, se anulan mutuamente."
        }
      ]
    },
    {
      category: "Simplificación y Operaciones",
      items: [
        {
          name: "Descomposición y Extracción",
          formula: "\\sqrt{k^2 \\cdot a} = k\\sqrt{a}",
          desc: "Cualquier factor que sea un cuadrado perfecto sale fuera del radical multiplicando."
        },
        {
          name: "Suma y Resta de Semejantes",
          formula: "p\\sqrt[n]{x} \\pm q\\sqrt[n]{x} = (p \\pm q)\\sqrt[n]{x}",
          desc: "Solo pueden sumarse o restarse radicales semejantes (mismo índice y mismo radicando)."
        },
        {
          name: "Multiplicación de Monomios",
          formula: "(p\\sqrt[n]{a})(q\\sqrt[n]{b}) = (p \\cdot q)\\sqrt[n]{a \\cdot b}",
          desc: "Se multiplican coeficientes entre sí y radicandos entre sí bajo el mismo índice."
        }
      ]
    },
    {
      category: "Racionalización",
      items: [
        {
          name: "Monomio Cuadrado Simple",
          formula: "\\frac{a}{\\sqrt{b}} = \\frac{a\\sqrt{b}}{b}",
          desc: "Se multiplica numerador y denominador por la misma raíz cuadrada."
        },
        {
          name: "Binomio Conjugado",
          formula: "\\frac{k}{\\sqrt{a} \\pm \\sqrt{b}} = \\frac{k(\\sqrt{a} \\mp \\sqrt{b})}{a - b}",
          desc: "Aprovecha la diferencia de cuadrados (x+y)(x-y) = x² - y² invirtiendo el signo central."
        }
      ]
    },
    {
      category: "Exponentes Fraccionarios",
      items: [
        {
          name: "Equivalencia Exponente Fraccionario",
          formula: "\\sqrt[n]{a^m} = a^{\\frac{m}{n}}",
          desc: "El exponente interior 'm' va en el numerador; el índice 'n' va en el denominador."
        },
        {
          name: "Exponente Fraccionario Negativo",
          formula: "a^{-\\frac{m}{n}} = \\frac{1}{a^{\\frac{m}{n}}} = \\frac{1}{\\sqrt[n]{a^m}}",
          desc: "El exponente negativo invierte la base al denominador."
        }
      ]
    }
  ],

  // Lista de Insignias y Logros
  achievements: [
    { id: "ach_realm1", title: "Raíz del Origen", desc: "Completaste el Nivel 1: ¿Qué son los Radicales?", icon: "🌱" },
    { id: "ach_realm2", title: "Ojo del Basilisco", desc: "Completaste el Nivel 2: Tipos de Raíces", icon: "💎" },
    { id: "ach_realm3", title: "Guardián de las Leyes", desc: "Completaste el Nivel 3: Propiedades Fundamentales", icon: "📜" },
    { id: "ach_realm4", title: "Maestro Herrero", desc: "Completaste el Nivel 4: Simplificación de Radicales", icon: "🔨" },
    { id: "ach_realm5", title: "Señor de la Alquimia", desc: "Completaste el Nivel 5: Operaciones con Radicales", icon: "⚔️" },
    { id: "ach_realm6", title: "Purificador de Denominadores", desc: "Completaste el Nivel 6: Racionalización", icon: "🌊" },
    { id: "ach_realm7", title: "Caminante Cuántico", desc: "Completaste el Nivel 7: Potencias y Exponentes", icon: "⚡" },
    { id: "ach_crown", title: "Corona del Rey Radical", desc: "Aprobaste el Gran Examen Final de la Ciudadela con 80% o más", icon: "👑" },
    { id: "ach_speed", title: "Torbellino Relámpago", desc: "Resolviste 5 preguntas seguidas en contrarreloj sin fallar", icon: "⏱️" },
    { id: "ach_scholar", title: "Erudito Implacable", desc: "Consultaste todas las fórmulas en el Códice", icon: "📚" }
  ]
};

// Exportar globalmente
if (typeof window !== "undefined") {
  window.RADICAL_QUEST_DATA = RADICAL_QUEST_DATA;
}
